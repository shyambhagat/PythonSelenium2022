$(function() {
    //console.log("ready!");
    //alert('jQuery is Ready');
});