from django.apps import AppConfig


class ReportsConfig(AppConfig):
    name = 'Reports'
