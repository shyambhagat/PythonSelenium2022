from Masters.models import Customers
from Process.models import OrderDetails, Orders, ViewList
from django.db import models
from django.forms.widgets import TextInput

class OrdersReport(Orders):
    class Meta:
        proxy = True
        verbose_name = "Order Report"
        verbose_name_plural = "Order Report"
        db_table = "viewordersreport"
                
    def OrderTotal(self):
        ordTotal = 0.0
        for od in self.orderdetails_set.all(): # type: ignore
            if (od.UnitPrice is not None and od.Quantity is not None and od.Discount is not None):
                ordTotal += (float(od.UnitPrice) * od.Quantity * (1 - od.Discount))
        return("{:.2f}".format(ordTotal))
    
    OrderTotal.short_description = 'Order Total'
    
class OrderDetailsReport(OrderDetails):
        
    class Meta:
        proxy = True
        verbose_name = "Order Details Report"
        verbose_name_plural = "Order Details Report"
        db_table = "vieworderdetailsreport"
    
    def CustomerName(self):
        return self.Order.Customer
    
    CustomerName.short_description = "Customer Name"
    
    @property
    def Category(self):
        return self.Product.Category
    
    def OrderDate(self):
        return self.Order.OrderDate
    
    CustomerName.short_description = "Order Date"
    
    @property
    def CategoryDate(self):
        return self.Product.Category.InsertedDate

class CountrySummary(Customers):
    class Meta:
       proxy = True
       verbose_name = 'Country Summary'
       verbose_name_plural = 'Country Summary'
       
class ContinentSummary(Customers):
    class Meta:
       proxy = True
       verbose_name = 'Continent Summary'
       verbose_name_plural = 'Continent Summary'

class CategoryWiseReport(ViewList):
    class Meta:
        proxy = True
        verbose_name = "Category Wise Report"
        verbose_name_plural = "Category Wise Report"
        db_table = "viewcategorywisereport"