from Lists.models import Categories
from Reports.models import CategoryWiseReport
from django.utils import timezone
from django import forms

class CategoryWiseReportForm(forms.ModelForm):
    Category = forms.ModelChoiceField(queryset=Categories.objects.all())
    
    class Meta:
        model = CategoryWiseReport
        fields = ['id']