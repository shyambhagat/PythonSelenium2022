from Reports.forms import CategoryWiseReportForm
from Masters.models import Products
from django.db.models.fields import FloatField
from . import models
from django.contrib import admin
from import_export.admin import ExportMixin
from import_export import resources
from import_export.fields import Field
from django.db.models import F
from import_export.widgets import DateWidget, FloatWidget
from django.db.models.aggregates import Sum, Count
from django.contrib import messages
from django.contrib.admin.views.main import ChangeList
from django.db import models as dbModel
from django.forms.widgets import TextInput
import pandas as pd
import json

colors= ["#0099ff", "#e08b27", "#0bda51", "#0072bb", "#0ebfe9", 
         "#ff3d7f", "#8bc34a", "#fcb134", "#ea80fc", "#9df556",
         "#f5e628", "#23c6c8", "#ff8800", "#78909c", "#9933cc", "#673ab7"]
        
        
class ExportAdmin(ExportMixin, admin.ModelAdmin):
    pass

class ReportAdmin(ExportAdmin):
    actions = None
    show_full_result_count = False
    list_display_links = None

    def has_add_permission(self, request, obj=None):
        return False

    def has_delete_permission(self, request, obj=None):
        return False

    def has_change_permission(self, request, obj=None):
        return False

    def has_module_permission(self, request):
        return True
    
class OrderDetailsReportResource(resources.ModelResource):
    customerName = Field(attribute='Order__Customer', column_name='Customer')
    productName = Field(attribute='Product', column_name='Product Name')
    categoryName = Field(attribute='Product__Category', column_name='Category Name')
    orderDate = Field(attribute='Order__OrderDate', column_name='Order Date', widget=DateWidget(format="%m/%d/%Y"))
    total = Field(column_name='Total')
    
    class Meta:
        model = models.OrderDetailsReport
        fields = ('id', 'Order', 'customerName', 'productName', 'categoryName', 'orderDate', 'UnitPrice', 'Quantity', 'ViewDiscount', 'total')
        export_order = fields
        
    def dehydrate_total(self, orderItem):
        if (orderItem.UnitPrice is not None and orderItem.Quantity is not None and orderItem.Discount is not None):
            total = float(orderItem.UnitPrice) * orderItem.Quantity * (1 - orderItem.Discount)
            return total
        else:
            return 0

class OrdersReportAdmin(ReportAdmin):
    list_display = ['id', 'Customer', 'OrderDate', 'OrderTotal']
    list_filter = ['Customer', 'OrderDate']
    date_hierarchy = 'OrderDate'
    list_per_page = 15
    
    formfield_overrides = {
        dbModel.DecimalField: {'widget': TextInput(attrs={'class': 'text-right'}) },
        dbModel.FloatField: {'widget': TextInput(attrs={'class': 'text-right'}) },
    }
    #('id', ('amount', '%.2f EUR'), ('interest', '%.2f %%'))
    
admin.site.register(models.OrdersReport, OrdersReportAdmin)
        
class OrderDetailsReportAdmin(ReportAdmin):
    resource_class = OrderDetailsReportResource
    list_display = ['id', 'Order', 'CustomerName', 'Product', 'Category', 'OrderDate', 'UnitPrice', 'Quantity','ViewDiscount','Total']
    list_filter = ['Order__Customer', 'Product', 'Product__Category', 'Order__OrderDate', 'Order__Customer__Country']
    date_hierarchy = 'Order__OrderDate'
    list_per_page = 15
    
admin.site.register(models.OrderDetailsReport, OrderDetailsReportAdmin)

class CountrySummaryAdmin(ReportAdmin):
    change_list_template = 'admin/reports/country_summary_template.html'

    def changelist_view(self, request, extra_context=None):
        response = super().changelist_view(request, extra_context=extra_context)
        try:
            qs = response.context_data['cl'].queryset
        except (AttributeError, KeyError):
            return response
        #F('temp_tasks_duration')*F('tasks_count_distinct')
        metrics = {
            'CustomerCount': Count('CustomerCode', distinct=True),
            'OrdersCount': Count('orders__id', distinct=True),
            'OrdersSum': Sum((F('orders__orderdetails__UnitPrice')*F('orders__orderdetails__Quantity')*(1 - F('orders__orderdetails__Discount'))), output_field=FloatField())
        }
        response.context_data['summary'] = list(
            qs.values("Country").annotate(**metrics).order_by('-CustomerCount')
        )
        return response
    

admin.site.register(models.CountrySummary, CountrySummaryAdmin)

class ContinentSummaryAdmin(ReportAdmin):
    change_list_template = 'admin/reports/continent_summary_template.html'

    def changelist_view(self, request, extra_context=None):
        response = super().changelist_view(request, extra_context=extra_context)
        try:
            qs = response.context_data['cl'].queryset
        except (AttributeError, KeyError):
            return response
        #F('temp_tasks_duration')*F('tasks_count_distinct')
        metrics = {
            'CustomerCount': Count('CustomerCode', distinct=True),
            'OrdersCount': Count('orders__id', distinct=True),
            'OrdersSum': Sum((F('orders__orderdetails__UnitPrice')*F('orders__orderdetails__Quantity')*(1 - F('orders__orderdetails__Discount'))), output_field=FloatField())
        }
        summeryList = list(qs.values("Continent").annotate(**metrics).order_by('-CustomerCount'))
        response.context_data['summary'] = summeryList
        
        summeryList2 = list(qs.values("Continent", "orders__OrderDate__year").annotate(**metrics).order_by('-CustomerCount'))
        summeryDF = pd.DataFrame(summeryList2)
        summeryDF.rename(columns={"orders__OrderDate__year": "Year"}, inplace=True)
        summeryDF.sort_values(["Continent", "Year"], inplace=True)
        summeryDF.dropna(subset=['Year'], inplace=True)
        summeryDF["Year"] = summeryDF["Year"].astype('int')
        yearWiseSummerDF = summeryDF.pivot_table(index="Continent", columns= "Year", values="OrdersSum", aggfunc="sum", margins=True)
        yearWiseSummerDF = yearWiseSummerDF.rename_axis(None, axis=1).reset_index()
        count = 0
        series = []
        years = yearWiseSummerDF.columns.tolist()[1:]
        
        for index, row in yearWiseSummerDF.iterrows():
            series.append({
                "name": row["Continent"],
                "color": colors[count % (len(colors) -1)],
                "data": row.tolist()[1:-1],
                #"showInLegend": False 
            })
            count += 1
        
        series.pop()
        
        count = 0
        totalSeries = []
        
        for index, row in yearWiseSummerDF.iterrows():
            totalSeries.append({
                "name": row["Continent"],
                "color": colors[count % (len(colors) -1)],
                "y": row.tolist()[-1:][0],
                #"showInLegend": False 
            })
            count += 1
        
        totalSeries.pop()
        
        response.context_data['yearWiseData'] = yearWiseSummerDF.to_html(index=False, border = 0, float_format='%10.2f', classes="yearwisecontinent")
        response.context_data['chartSeriesData'] = json.dumps(series)
        response.context_data['chartPieSeriesData'] = json.dumps(totalSeries)
        response.context_data['chartCategoryData'] = json.dumps(years)        
        return response

admin.site.register(models.ContinentSummary, ContinentSummaryAdmin)

class CategoryWiseReportAdmin(ReportAdmin):
    change_list_template = 'admin/masters/common_list.html'
    def changelist_view(self, request, extra_context=None):
        if extra_context is None: extra_context = {}
        category_wise_form = CategoryWiseReportForm(request.POST or None)
        
        if category_wise_form.is_valid():
            categoryOption = int(request.POST.get('Category'))
            productList = list(Products.objects.filter(Category__id=categoryOption).values("ProductName", "Category__CategoryName"))
            summeryDF = pd.DataFrame(productList)
            summeryDF.rename(columns={"Category__CategoryName": "Category"}, inplace=True)
            extra_context['listdata'] = summeryDF.to_html(index=False, border = 0, float_format='%10.2f', classes="productcategorylist")

        extra_context["buttonname"] = "Search"            
        extra_context["form"] = category_wise_form
        extra_context["title"] = None
        return super(CategoryWiseReportAdmin, self).changelist_view(request, extra_context)

admin.site.register(models.CategoryWiseReport, CategoryWiseReportAdmin)