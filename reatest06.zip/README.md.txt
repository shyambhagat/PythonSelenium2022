# IOD Report Builder - React Application

A modern React-based report builder application converted from static HTML/CSS/JS to a proper React application using Vite.

## Features

- **Interactive Dashboard**: View sales, income, and order statistics
- **Multiple Tools**: Text, Chart, Image, Table, and Shape tools
- **AI Assistant**: Smart suggestions and chat interface
- **Multi-page Support**: Create and manage multiple report pages
- **Responsive Design**: Bootstrap-based responsive layout
- **Rich Text Editing**: Summernote integration for text editing

## Project Structure

```
report-builder-react/
├── public/
│   ├── css/           # Bootstrap and custom styles
│   ├── fonts/         # Poppins font family
│   ├── images/        # All image assets
│   └── js/            # jQuery, Bootstrap, and custom scripts
├── src/
│   ├── components/
│   │   ├── panels/    # Tool-specific panels (Chart, Table, etc.)
│   │   ├── Header.jsx
│   │   ├── Sidebar.jsx
│   │   ├── MainContent.jsx
│   │   ├── Footer.jsx
│   │   ├── ToolPanel.jsx
│   │   └── AssetPanel.jsx
│   ├── App.jsx
│   └── main.jsx
└── index.html
```

## Getting Started

### Prerequisites

- Node.js (v14 or higher)
- npm or yarn

### Installation

1. Navigate to the project directory:
```bash
cd report-builder-react
```

2. Install dependencies:
```bash
npm install
```

### Development

Start the development server:
```bash
npm run dev
```

The application will be available at `http://localhost:5173`

### Build for Production

Create a production build:
```bash
npm run build
```

Preview the production build:
```bash
npm run preview
```

## Components Overview

### Header
- Logo and application title
- Navigation menu (Preview, Download, Publish)
- User profile dropdown

### Sidebar
- Tool icons (Text, Chart, Image, Table, Shape, Asset)
- Expandable panels for each tool
- AI Assistant chat interface

### MainContent
- Multi-page tabbed interface
- Dashboard with KPI cards
- Charts and visualizations
- Page management

### Footer
- Navigation controls
- Zoom controls
- Grid toggle
- Settings

## Technologies Used

- **React 18**: Modern React with hooks
- **Vite**: Fast build tool and dev server
- **Bootstrap 5**: Responsive CSS framework
- **Bootstrap Icons**: Icon library
- **Summernote**: Rich text editor
- **jQuery**: For Bootstrap and Summernote compatibility

## Features in Detail

### Tool Panels

1. **Text Tool**: Add and edit text in documents
2. **Chart Tool**: Create various chart types with customization options
3. **Image Tool**: Upload and manage images
4. **Table Tool**: Create and style data tables
5. **Shape Tool**: Draw and modify shapes
6. **Asset Tool**: AI assistant for smart suggestions

### Chart Types Supported
- Area Chart
- Line Chart
- Pie Chart
- Bar Chart
- Stacked Chart
- Bullet Chart
- Grouped Chart
- Waterfall Chart
- Multi Chart
- Tree Chart
- Doughnut Chart

### Table Features
- Customizable colors (background, header, rows)
- Alternate row styling
- Insights integration
- Adjustable size and position

## Browser Support

- Chrome (latest)
- Firefox (latest)
- Safari (latest)
- Edge (latest)

## License

This project is proprietary software.

## Author

IOD Team
