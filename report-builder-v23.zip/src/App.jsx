import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { ReportProvider } from './context/ReportContext';
import HomePage from './components/HomePage';
import ReportWizard from './components/ReportWizard';
import ReportEditor from './components/ReportEditor';

function App() {
  return (
    <ReportProvider>
      <Router>
        <div className="overflow-hidden">
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/wizard" element={<ReportWizard />} />
            <Route path="/editor/:reportId" element={<ReportEditor />} />
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>

          <div id="pageLoad" className="pageLoad display-none">
            <div className="d-flex justify-content-center h-100 align-items-center">
              <div className="spinner-border">
                <span className="visually-hidden">Loading...</span>
              </div>
            </div>
          </div>
        </div>
      </Router>
    </ReportProvider>
  );
}

export default App;
