import React, { createContext, useContext, useState, useEffect } from 'react';
import PropTypes from 'prop-types';

const ReportContext = createContext();

// eslint-disable-next-line react-refresh/only-export-components
export const useReports = () => {
  const context = useContext(ReportContext);
  if (!context) {
    throw new Error('useReports must be used within a ReportProvider');
  }
  return context;
};

export const ReportProvider = ({ children }) => {
  const [reports, setReports] = useState(() => {
    // Load reports from localStorage on initial load
    const savedReports = localStorage.getItem('reportBuilderReports');
    return savedReports ? JSON.parse(savedReports) : [];
  });

  // Save reports to localStorage whenever they change
  useEffect(() => {
    localStorage.setItem('reportBuilderReports', JSON.stringify(reports));
  }, [reports]);

  const createReport = (name, description = '') => {
    const newReport = {
      id: Date.now().toString(),
      name,
      description,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      pages: [
        {
          id: 'page-1',
          name: 'Page 1',
          pageSize: 'A4',
          orientation: 'portrait',
          elements: [],
        }
      ]
    };

    setReports(prev => [...prev, newReport]);
    return newReport;
  };

  const getReport = (id) => {
    return reports.find(report => report.id === id);
  };

  const updateReport = (id, updates) => {
    setReports(prev =>
      prev.map(report =>
        report.id === id
          ? { ...report, ...updates, updatedAt: new Date().toISOString() }
          : report
      )
    );
  };

  const deleteReport = (id) => {
    setReports(prev => prev.filter(report => report.id !== id));
  };

  const addPage = (reportId) => {
    setReports(prev =>
      prev.map(report => {
        if (report.id === reportId) {
          const newPageNumber = report.pages.length + 1;
          const newPage = {
            id: `page-${Date.now()}`,
            name: `Page ${newPageNumber}`,
            pageSize: 'A4',
            orientation: 'portrait',
            elements: []
          };
          return {
            ...report,
            pages: [...report.pages, newPage],
            updatedAt: new Date().toISOString()
          };
        }
        return report;
      })
    );
  };

  const deletePage = (reportId, pageId) => {
    setReports(prev =>
      prev.map(report => {
        if (report.id === reportId) {
          const updatedPages = report.pages.filter(page => page.id !== pageId);
          // Ensure at least one page remains
          if (updatedPages.length === 0) {
            return report;
          }
          return {
            ...report,
            pages: updatedPages,
            updatedAt: new Date().toISOString()
          };
        }
        return report;
      })
    );
  };

  const updatePageName = (reportId, pageId, newName) => {
    setReports(prev =>
      prev.map(report => {
        if (report.id === reportId) {
          return {
            ...report,
            pages: report.pages.map(page =>
              page.id === pageId ? { ...page, name: newName } : page
            ),
            updatedAt: new Date().toISOString()
          };
        }
        return report;
      })
    );
  };

  const updatePageSettings = (reportId, pageId, updates) => {
    setReports(prev =>
      prev.map(report => {
        if (report.id !== reportId) return report;
        return {
          ...report,
          pages: report.pages.map(page =>
            page.id === pageId ? { ...page, ...updates } : page
          ),
          updatedAt: new Date().toISOString(),
        };
      })
    );
  };

  const addElementToPage = (reportId, pageId, element) => {
    setReports(prev =>
      prev.map(report => {
        if (report.id === reportId) {
          return {
            ...report,
            pages: report.pages.map(page =>
              page.id === pageId
                ? { ...page, elements: [...page.elements, element] }
                : page
            ),
            updatedAt: new Date().toISOString()
          };
        }
        return report;
      })
    );
  };

  const updateElementOnPage = (reportId, pageId, elementId, updates) => {
    setReports(prev =>
      prev.map(report => {
        if (report.id !== reportId) {
          return report;
        }

        return {
          ...report,
          pages: report.pages.map(page => {
            if (page.id !== pageId) {
              return page;
            }

            return {
              ...page,
              elements: page.elements.map(element =>
                element.id === elementId ? { ...element, ...updates } : element
              )
            };
          }),
          updatedAt: new Date().toISOString()
        };
      })
    );
  };

  const removeElementFromPage = (reportId, pageId, elementId) => {
    setReports(prev =>
      prev.map(report => {
        if (report.id !== reportId) {
          return report;
        }

        return {
          ...report,
          pages: report.pages.map(page => {
            if (page.id !== pageId) {
              return page;
            }

            return {
              ...page,
              elements: page.elements.filter(element => element.id !== elementId)
            };
          }),
          updatedAt: new Date().toISOString()
        };
      })
    );
  };

  const duplicateElement = (reportId, pageId, elementId) => {
    setReports(prev =>
      prev.map(report => {
        if (report.id !== reportId) {
          return report;
        }

        return {
          ...report,
          pages: report.pages.map(page => {
            if (page.id !== pageId) {
              return page;
            }

            const elementToCopy = page.elements.find(el => el.id === elementId);
            if (!elementToCopy) {
              return page;
            }

            // Create a new element with a new ID and slightly offset position
            const newElement = {
              ...elementToCopy,
              id: (typeof crypto !== 'undefined' && crypto.randomUUID) ? crypto.randomUUID() : `${Date.now()}`,
              x: elementToCopy.x + 20,
              y: elementToCopy.y + 20,
            };

            return {
              ...page,
              elements: [...page.elements, newElement]
            };
          }),
          updatedAt: new Date().toISOString()
        };
      })
    );
  };

  const value = {
    reports,
    createReport,
    getReport,
    updateReport,
    deleteReport,
    addPage,
    deletePage,
    updatePageName,
    updatePageSettings,
    addElementToPage,
    updateElementOnPage,
    removeElementFromPage,
    duplicateElement
  };

  return (
    <ReportContext.Provider value={value}>
      {children}
    </ReportContext.Provider>
  );
};

ReportProvider.propTypes = {
  children: PropTypes.node.isRequired,
};
