export const TEXT_STYLE_DRAG_TYPE = 'application/vnd.iod.text-style';
export const CHART_DRAG_TYPE = 'application/vnd.iod.chart';
export const IMAGE_DRAG_TYPE = 'application/vnd.iod.image';
export const TABLE_DRAG_TYPE = 'application/vnd.iod.table';
export const SHAPE_DRAG_TYPE = 'application/vnd.iod.shape';

// Alternative names for consistency
export const TEXT_DRAG_TYPE = TEXT_STYLE_DRAG_TYPE;