import React from 'react';
import PropTypes from 'prop-types';
import TextPanel from './panels/TextPanel';
import ChartPanel from './panels/ChartPanel';
import ImagePanel from './panels/ImagePanel';
import TablePanel from './panels/TablePanel';
import ShapePanel from './panels/ShapePanel';

const ToolPanel = ({ activeTool, onAddText }) => {
  return (
    <>
      {activeTool === 'text' && <TextPanel onAddText={onAddText} />}
      {activeTool === 'chart' && <ChartPanel />}
      {activeTool === 'image' && <ImagePanel />}
      {activeTool === 'table' && <TablePanel />}
      {activeTool === 'shape' && <ShapePanel />}
    </>
  );
};

ToolPanel.propTypes = {
  activeTool: PropTypes.string.isRequired,
  onAddText: PropTypes.func,
};

export default ToolPanel;
