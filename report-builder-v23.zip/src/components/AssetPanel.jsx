import React, { useState } from 'react';
import TextPanel from './panels/TextPanel';
import ChartPanel from './panels/ChartPanel';
import ImagePanel from './panels/ImagePanel';
import TablePanel from './panels/TablePanel';
import ShapePanel from './panels/ShapePanel';

const TABS = [
  { key: 'text', label: 'Text', Comp: TextPanel },
  { key: 'charts', label: 'Charts', Comp: ChartPanel },
  { key: 'image', label: 'Images', Comp: ImagePanel },
  { key: 'table', label: 'Tables', Comp: TablePanel },
  { key: 'shape', label: 'Shapes', Comp: ShapePanel },
];

const AssetPanel = () => {
  const [activeTab, setActiveTab] = useState('text');

  const ActiveComponent = TABS.find((t) => t.key === activeTab)?.Comp;

  return (
    <div className="tool-panel" data-tool="asset">
      <div className="asset-panel-tabs">
        {TABS.map((tab) => (
          <button
            key={tab.key}
            className={`asset-tab-button ${activeTab === tab.key ? 'active' : ''}`}
            onClick={() => setActiveTab(tab.key)}
          >
            {tab.label}
          </button>
        ))}
      </div>
      <div className="asset-panel-content">
        {ActiveComponent && <ActiveComponent />}
      </div>
    </div>
  );
};

export default AssetPanel;