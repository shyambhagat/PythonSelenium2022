import React, { useMemo } from 'react';
import PropTypes from 'prop-types';

const MIN_ZOOM = 50;
const MAX_ZOOM = 200;

const Footer = ({
  zoomValue,
  onZoomChange,
  onZoomReset,
  onToggleGrid,
  onUndoGrid,
  onRedoGrid,
  canUndo,
  canRedo,
  onFullscreenToggle,
  isFullscreen,
  onOpenSettings,
  onCopyElement,
  canCopy,
}) => {
  const sliderBackground = useMemo(() => {
    const percent = ((zoomValue - MIN_ZOOM) / (MAX_ZOOM - MIN_ZOOM)) * 100;
    return {
      background: `linear-gradient(to right, #859BC1 ${percent}%, #dbe3f1 ${percent}%)`,
    };
  }, [zoomValue]);

  const handleZoomChange = (event) => {
    onZoomChange(Number(event.target.value));
  };

  return (
    <footer
      className="d-flex justify-content-between align-items-center px-4 pb-1 border-top bg-transparent border-top-0 pe-md-5 me-md-5 pe-4 me-4"
      id="footerWrapper"
    >
      <div className="d-flex gap-2 footerbtns py-0 justify-content-between align-items-center">
        <div className="pe-3 d-flex gap-2 py-0 align-items-center justify-content-center border-end border-h-20">
          <button
            className={`btn btn-sm border-0 pe-0 ${canUndo ? 'enabled' : ''}`}
            type="button"
            disabled={!canUndo}
            onClick={onUndoGrid}
          >
            <img src="/images/arrowLeft-icon.svg" alt="" width="13" height="12" />
          </button>
          <button
            className={`btn btn-sm border-0 ${canRedo ? 'enabled' : ''}`}
            type="button"
            disabled={!canRedo}
            onClick={onRedoGrid}
          >
            <img src="/images/arrowRight-icon.svg" alt="" width="13" height="12" />
          </button>
        </div>
        <button className="btn btn-sm" type="button" onClick={onToggleGrid}>
          <img src="/images/clone-icon.svg" alt="" width="14" height="14" />
        </button>
        <button
          className={`btn btn-sm ${canCopy ? 'enabled' : ''}`}
          type="button"
          onClick={onCopyElement}
          disabled={!canCopy}
          title="Copy selected element (Ctrl+C)"
        >
          <img src="/images/copy-icon.svg" alt="Copy" width="14" height="14" />
        </button>
      </div>

      <div className="d-flex align-items-center">
        <div className="zoom-slider">
          <input
            type="range"
            id="zoomRange"
            min={MIN_ZOOM}
            max={MAX_ZOOM}
            value={zoomValue}
            onChange={handleZoomChange}
            style={sliderBackground}
          />
          <span id="zoomValue" className="zoom-value">
            {zoomValue}%
          </span>

          <button
            type="button"
            className="btn btn-link p-0 zoom-icon"
            title={isFullscreen ? 'Exit Fullscreen' : 'Fullscreen'}
            onClick={onFullscreenToggle}
          >
            <img
              src={isFullscreen ? '/images/fullscreen-exit-icon.svg' : '/images/fullscreen-icon.svg'}
              alt="fullscreen icon"
              width="14"
              height="14"
            />
          </button>

          <button
            type="button"
            className="btn btn-link p-0 zoom-icon"
            title="Reset Zoom"
            onClick={onZoomReset}
          >
            <img src="/images/arrowLeft-icon.svg" alt="reset icon" width="13" height="12" />
          </button>
        </div>
      </div>

      <div className="d-flex align-items-center gap-2">
        <button className="btn btn-sm border-0 pe-0" type="button" onClick={onToggleGrid}>
          <img src="/images/grid-icon.svg" alt="Grid icon" width="18" height="18" />
        </button>
        <button className="btn btn-sm border-0 pe-0" type="button" onClick={onOpenSettings} aria-label="Open Page Settings">
          <img src="/images/settings-icon.svg" alt="Settings icon" width="14" height="14" />
        </button>
      </div>
    </footer>
  );
};

Footer.propTypes = {
  zoomValue: PropTypes.number.isRequired,
  onZoomChange: PropTypes.func.isRequired,
  onZoomReset: PropTypes.func.isRequired,
  onToggleGrid: PropTypes.func.isRequired,
  onUndoGrid: PropTypes.func.isRequired,
  onRedoGrid: PropTypes.func.isRequired,
  canUndo: PropTypes.bool.isRequired,
  canRedo: PropTypes.bool.isRequired,
  onFullscreenToggle: PropTypes.func.isRequired,
  isFullscreen: PropTypes.bool.isRequired,
  onOpenSettings: PropTypes.func,
  onCopyElement: PropTypes.func,
  canCopy: PropTypes.bool,
};

export default Footer;
