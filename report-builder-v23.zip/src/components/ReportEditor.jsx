import React from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useReports } from '../context/ReportContext';
import Header from './Header';
import Sidebar from './Sidebar';
import MainContent from './MainContent';
import PageSidebar from './PageSidebar';
import Footer from './Footer';
import PageSettingsModal from './PageSettingsModal';

const initialGridState = {
  history: [false],
  index: 0,
};

const gridReducer = (state, action) => {
  switch (action.type) {
    case 'toggle': {
      const currentValue = state.history[state.index] ?? false;
      const truncated = state.history.slice(0, state.index + 1);
      const nextHistory = [...truncated, !currentValue];
      return { history: nextHistory, index: nextHistory.length - 1 };
    }
    case 'undo':
      if (state.index === 0) {
        return state;
      }
      return { ...state, index: state.index - 1 };
    case 'redo':
      if (state.index >= state.history.length - 1) {
        return state;
      }
      return { ...state, index: state.index + 1 };
    default:
      return state;
  }
};

const ReportEditor = () => {
  const { reportId } = useParams();
  const navigate = useNavigate();
  const { getReport, addElementToPage, updatePageSettings, duplicateElement } = useReports();
  const [activePage, setActivePage] = React.useState(null);
  const [gridState, dispatchGrid] = React.useReducer(gridReducer, initialGridState);
  const gridEnabled = gridState.history[gridState.index] ?? false;
  const [zoomValue, setZoomValue] = React.useState(100);
  const pageContentRef = React.useRef(null);
  const [isFullscreen, setIsFullscreen] = React.useState(false);
  const [showPageSettings, setShowPageSettings] = React.useState(false);
  const [selectedElement, setSelectedElement] = React.useState(null);

  const report = getReport(reportId);

  // Set initial active page
  React.useEffect(() => {
    if (report && report.pages && report.pages.length > 0 && !activePage) {
      setActivePage(report.pages[0].id);
    }
  }, [report, activePage]);

  // If report doesn't exist, redirect to home
  React.useEffect(() => {
    if (!report) {
      navigate('/');
    }
  }, [report, navigate]);

  const handleAddText = (textElement) => {
    if (activePage) {
      addElementToPage(reportId, activePage, textElement);
    }
  };
  const handleToggleGrid = () => dispatchGrid({ type: 'toggle' });
  const handleUndoGrid = () => dispatchGrid({ type: 'undo' });
  const handleRedoGrid = () => dispatchGrid({ type: 'redo' });

  const handleFullscreenToggle = React.useCallback(async () => {
    if (!document.fullscreenElement && pageContentRef.current) {
      await pageContentRef.current.requestFullscreen();
    } else if (document.fullscreenElement) {
      await document.exitFullscreen();
    }
  }, []);

  const handleOpenSettings = () => setShowPageSettings(true);
  const handleCloseSettings = () => setShowPageSettings(false);
  const handleSaveSettings = (updates) => {
    if (!report || !activePage) return;
    updatePageSettings(reportId, activePage, updates);
    setShowPageSettings(false);
  };

  const handleCopyElement = () => {
    if (selectedElement) {
      duplicateElement(reportId, selectedElement.pageId, selectedElement.elementId);
    }
  };

  React.useEffect(() => {
    const handleFullscreenChange = () => {
      setIsFullscreen(Boolean(document.fullscreenElement));
    };

    document.addEventListener('fullscreenchange', handleFullscreenChange);
    return () => {
      document.removeEventListener('fullscreenchange', handleFullscreenChange);
    };
  }, []);

  if (!report) {
    return null;
  }

  return (
    <div className="overflow-hidden">
      <Header reportName={report.name} />
      <div className="wrapper d-flex align-items-stretch">
        <PageSidebar
          reportId={reportId}
          pages={report.pages || []}
          activePageId={activePage || (report.pages?.[0]?.id)}
          onSelectPage={setActivePage}
        />
        <MainContent
          reportId={reportId}
          report={report}
          activePageId={activePage || (report.pages?.[0]?.id)}
          onActivePageChange={setActivePage}
          gridEnabled={gridEnabled}
          zoomValue={zoomValue}
          contentRef={pageContentRef}
          onElementSelect={setSelectedElement}
        />
        <Sidebar reportId={reportId} activePage={activePage} onAddText={handleAddText} />
      </div>
      <Footer
        zoomValue={zoomValue}
        onZoomChange={setZoomValue}
        onZoomReset={() => setZoomValue(100)}
        onToggleGrid={handleToggleGrid}
        onUndoGrid={handleUndoGrid}
        onRedoGrid={handleRedoGrid}
        canUndo={gridState.index > 0}
        canRedo={gridState.index < gridState.history.length - 1}
        onFullscreenToggle={handleFullscreenToggle}
        isFullscreen={isFullscreen}
        onOpenSettings={handleOpenSettings}
        onCopyElement={handleCopyElement}
        canCopy={!!selectedElement}
      />

      <PageSettingsModal
        isOpen={showPageSettings}
        onClose={handleCloseSettings}
        onSave={handleSaveSettings}
        page={(report && activePage) ? (report.pages || []).find(p => p.id === activePage) : null}
      />
    </div>
  );
};

export default ReportEditor;
