import React from 'react';
import PropTypes from 'prop-types';
import Swal from 'sweetalert2';
import html2canvas from 'html2canvas';
import { useReports } from '../context/ReportContext';

const PageSidebar = ({ reportId, pages, activePageId, onSelectPage }) => {
  const { addPage, deletePage } = useReports();
  const listRef = React.useRef(null);
  const [thumbnails, setThumbnails] = React.useState({});

  const handleAddPage = () => {
    addPage(reportId);
  };

  // Generate thumbnail for a page
  const generateThumbnail = React.useCallback(async (pageId) => {
    try {
      // Find the page container in the DOM
      const pageContainer = document.querySelector('.page-container');
      if (!pageContainer) return;

      // Find the current page to check orientation
      const currentPage = pages.find(p => p.id === pageId);
      const isLandscape = currentPage?.orientation === 'landscape';

      // Capture the page as canvas
      const sourceCanvas = await html2canvas(pageContainer, {
        scale: 0.15, // Small scale for thumbnail
        backgroundColor: '#ffffff',
        logging: false,
        useCORS: true,
        allowTaint: true,
      });

      let finalCanvas = sourceCanvas;

      // For landscape pages, rotate the canvas 90 degrees counter-clockwise
      // So when the thumbnail container rotates 90 degrees clockwise, it appears correct
      if (isLandscape) {
        const rotatedCanvas = document.createElement('canvas');
        const ctx = rotatedCanvas.getContext('2d');

        // Swap width and height for rotation
        rotatedCanvas.width = sourceCanvas.height;
        rotatedCanvas.height = sourceCanvas.width;

        // Rotate and draw
        ctx.translate(0, sourceCanvas.width);
        ctx.rotate(-Math.PI / 2);
        ctx.drawImage(sourceCanvas, 0, 0);

        finalCanvas = rotatedCanvas;
      }

      // Convert to data URL
      const dataUrl = finalCanvas.toDataURL('image/png');

      // Update thumbnails state
      setThumbnails(prev => ({
        ...prev,
        [pageId]: dataUrl
      }));
    } catch (error) {
      console.error('Error generating thumbnail:', error);
    }
  }, [pages]);

  // Generate thumbnails when pages or page content changes
  React.useEffect(() => {
    if (!pages || pages.length === 0) return;

    // Generate thumbnail for active page whenever it changes
    if (activePageId) {
      const currentPage = pages.find(p => p.id === activePageId);
      if (!currentPage) return;

      // Small delay to ensure DOM is ready after content changes
      const timer = setTimeout(() => {
        generateThumbnail(activePageId);
      }, 500);
      return () => clearTimeout(timer);
    }
  }, [pages, activePageId, generateThumbnail]);

  // Monitor page elements changes to update thumbnails
  React.useEffect(() => {
    if (!activePageId || !pages) return;

    const currentPage = pages.find(p => p.id === activePageId);
    if (!currentPage) return;

    // Regenerate thumbnail when elements change
    const elementsJSON = JSON.stringify(currentPage.elements || []);

    const timer = setTimeout(() => {
      generateThumbnail(activePageId);
    }, 500);
    return () => clearTimeout(timer);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [JSON.stringify(pages?.find(p => p.id === activePageId)?.elements), activePageId, generateThumbnail]);

  const handleDeletePage = (pageId) => {
    if (!pages || pages.length <= 1) {
      Swal.fire({
        title: 'Cannot Delete Page',
        text: 'At least one page is required.',
        icon: 'info',
        confirmButtonText: 'OK',
        confirmButtonColor: '#0d6efd',
        heightAuto: false
      });
      return;
    }

    Swal.fire({
      title: 'Delete Page?',
      text: 'This action cannot be undone.',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#dc3545',
      cancelButtonColor: '#6c757d',
      confirmButtonText: 'Yes, delete it',
      cancelButtonText: 'Cancel',
      heightAuto: false
    }).then((result) => {
      if (result.isConfirmed) {
        // If deleting the active page, select a neighbor page first
        if (activePageId === pageId) {
          const index = pages.findIndex(p => p.id === pageId);
          const fallback = pages[index + 1] || pages[index - 1] || pages[0];
          if (fallback) {
            onSelectPage && onSelectPage(fallback.id);
          }
        }

        deletePage(reportId, pageId);
      }
    });
  };

  // Auto-scroll active page into view whenever it changes or pages update
  React.useEffect(() => {
    if (!listRef.current || !activePageId) return;
    const el = listRef.current.querySelector(`[data-page-id="${activePageId}"]`);
    if (el && typeof el.scrollIntoView === 'function') {
      el.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
    }
  }, [activePageId, pages?.length]);

  const handleListKeyDown = (e) => {
    if (!pages || pages.length === 0) return;
    const currentIndex = Math.max(0, pages.findIndex(p => p.id === activePageId));
    let nextIndex = currentIndex;
    switch (e.key) {
      case 'ArrowUp':
      case 'ArrowLeft':
        nextIndex = Math.max(0, currentIndex - 1);
        break;
      case 'ArrowDown':
      case 'ArrowRight':
        nextIndex = Math.min(pages.length - 1, currentIndex + 1);
        break;
      case 'Home':
        nextIndex = 0;
        break;
      case 'End':
        nextIndex = pages.length - 1;
        break;
      default:
        return; // ignore other keys
    }
    e.preventDefault();
    const nextPage = pages[nextIndex];
    if (nextPage && onSelectPage) {
      onSelectPage(nextPage.id);
      // Move focus to the newly active thumb after render
      requestAnimationFrame(() => {
        const el = listRef.current?.querySelector(`[data-page-id="${nextPage.id}"]`);
        el?.focus();
      });
    }
  };

  // Thumbnails fit portrait and landscape by scaling an inner paper box
  // to the fixed thumbnail viewport while preserving aspect ratio.
  const PAGE_SIZES = {
    A4: { w: 210, h: 297 },
    Letter: { w: 216, h: 279 },
  };

  const getAspect = (page) => {
    const size = PAGE_SIZES[page?.pageSize] || PAGE_SIZES.A4;
    // Always use portrait aspect; landscape is handled by rotating the whole thumbnail
    return `${size.w} / ${size.h}`;
  };

  return (
    <aside id="pageSidebar" aria-label="Pages Sidebar">
      <div className="page-sidebar-inner">
        <button
          type="button"
          className="btn btn-primary add-page-btn"
          onClick={handleAddPage}
          aria-label="Add Page"
        >
          <img src="/images/pluswithborder-icon.svg" alt="Add" width="16" height="16" />
          <span className="ms-2">Add Page</span>
        </button>

        <div
          className="page-list"
          role="listbox"
          aria-label="Pages"
          aria-activedescendant={activePageId ? `page-thumb-${activePageId}` : undefined}
          onKeyDown={handleListKeyDown}
          ref={listRef}
          tabIndex={0}
        >
          {pages && pages.map((page, idx) => (
            <div
              key={page.id}
              id={`page-thumb-${page.id}`}
              role="option"
              aria-selected={activePageId === page.id}
              data-page-id={page.id}
              data-orientation={page?.orientation || 'portrait'}
              tabIndex={activePageId === page.id ? 0 : -1}
              className={`page-thumb ${activePageId === page.id ? 'active' : ''}`}
              onClick={() => onSelectPage && onSelectPage(page.id)}
            >
              <button
                type="button"
                className="page-delete-btn"
                title="Delete page"
                aria-label={`Delete Page ${idx + 1}`}
                onClick={(e) => { e.stopPropagation(); handleDeletePage(page.id); }}
              >
                <img src="/images/deleteRed-icon.svg" width="14" height="14" alt="Delete" />
              </button>

              <div className="page-thumb-canvas" aria-hidden="true">
                {thumbnails[page.id] ? (
                  <img
                    src={thumbnails[page.id]}
                    alt={`Preview of page ${idx + 1}`}
                    className="page-thumb-preview"
                    style={{
                      aspectRatio: getAspect(page),
                      height: 'auto',
                      width: '100%',
                    }}
                  />
                ) : (
                  <div
                    className="page-thumb-paper"
                    style={{
                      aspectRatio: getAspect(page),
                      height: 'auto',
                      width: '100%',
                    }}
                  />
                )}
              </div>

              <span className="page-number-badge" aria-hidden="true">{idx + 1}</span>
            </div>
          ))}
        </div>
      </div>
    </aside>
  );
};

PageSidebar.propTypes = {
  reportId: PropTypes.string.isRequired,
  pages: PropTypes.arrayOf(PropTypes.shape({
    id: PropTypes.string.isRequired,
    name: PropTypes.string.isRequired,
  })).isRequired,
  activePageId: PropTypes.string,
  onSelectPage: PropTypes.func,
};

export default PageSidebar;
