import React from 'react';
import PropTypes from 'prop-types';
import { Link } from 'react-router-dom';

const Header = ({ reportName = 'Untitled' }) => {
  return (
    <header className="navbar px-3 d-flex justify-content-between align-items-center">
      <div className="d-flex align-items-center gap-5">
        <Link to="/">
          <img src="/images/logo.svg" alt="Logo" height="30" />
        </Link>

        <div className="d-flex align-items-end">
          <div>
            <img src="/images/edit-text.svg" alt="Edit text icon" width="16" height="auto" />
          </div>

          <div className="d-md-flex flex-md-column ps-2 lh-sm">
            <div className="font-12">Report </div>
            <div className="font-16">{reportName}</div>
          </div>
        </div>
      </div>

      {/* Right buttons */}
      <div className="float-end d-flex align-items-center">
        <nav className="navbar navbar-expand-lg navbar-light bg-light me-md-4 me-3 py-0">
          <div className="container-fluid">
            <button
              className="navbar-toggler"
              type="button"
              data-bs-toggle="collapse"
              data-bs-target="#navbarSupportedContent"
              aria-controls="navbarSupportedContent"
              aria-expanded="false"
              aria-label="Toggle navigation"
            >
              <span className="navbar-toggler-icon"></span>
            </button>
            <div className="collapse navbar-collapse" id="navbarSupportedContent">
              <ul className="navbar-nav me-auto mb-2 mb-lg-0 gap-3 font-12">
                <li className="nav-item d-flex align-items-center">
                  <img src="/images/preview-icon.svg" alt="preview icon" width="18" height="18" />
                  <a className="nav-link active" aria-current="page" href="#">
                    Preview
                  </a>
                </li>

                <li className="nav-item d-flex align-items-center dropdown">
                  <img src="/images/download-icon.svg" alt="download icon" width="15" height="18" />
                  <a
                    className="nav-link dropdown-toggle"
                    href="#"
                    id="navbarDropdown"
                    role="button"
                    data-bs-toggle="dropdown"
                    aria-expanded="false"
                  >
                    Download
                  </a>
                  <ul className="dropdown-menu font-12" aria-labelledby="navbarDropdown">
                    <li>
                      <a className="dropdown-item" href="#">
                        Test 1
                      </a>
                    </li>
                    <li>
                      <hr className="dropdown-divider" />
                    </li>
                    <li>
                      <a className="dropdown-item" href="#">
                        Test 2
                      </a>
                    </li>
                  </ul>
                </li>
                <li className="nav-item d-flex align-items-center">
                  <img src="/images/publish-icon.svg" alt="publish icon" width="20" height="20" />
                  <a className="nav-link" href="#">
                    Publish
                  </a>
                </li>
              </ul>
            </div>
          </div>
        </nav>

        <div className="dropdown d-flex">
          <span className="rounded-circle usernameicon me-2">BA</span>
          <button className="dropdown-toggle border-0 bg-transparent" data-bs-toggle="dropdown"></button>
          <ul className="dropdown-menu dropdown-menu-end font-12">
            <li>
              <a className="dropdown-item" href="#">
                Profile
              </a>
            </li>
            <li>
              <a className="dropdown-item" href="#">
                Logout
              </a>
            </li>
          </ul>
        </div>
      </div>
    </header>
  );
};

Header.propTypes = {
  reportName: PropTypes.string,
};

export default Header;
