import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useReports } from '../context/ReportContext';

const ReportWizard = () => {
  const navigate = useNavigate();
  const { createReport } = useReports();
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    template: 'blank',
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleNext = () => {
    if (step === 1 && !formData.name.trim()) {
      alert('Please enter a report name');
      return;
    }
    setStep(prev => prev + 1);
  };

  const handleBack = () => {
    setStep(prev => prev - 1);
  };

  const handleCreate = () => {
    if (!formData.name.trim()) {
      alert('Please enter a report name');
      return;
    }

    const newReport = createReport(formData.name, formData.description);
    navigate(`/editor/${newReport.id}`);
  };

  const templates = [
    {
      id: 'blank',
      name: 'Blank Report',
      description: 'Start with a blank page and build from scratch',
      icon: 'bi-file-earmark'
    },
    {
      id: 'dashboard',
      name: 'Dashboard',
      description: 'Pre-configured dashboard layout with charts',
      icon: 'bi-graph-up',
      disabled: true
    },
    {
      id: 'table',
      name: 'Data Table',
      description: 'Table-focused report template',
      icon: 'bi-table',
      disabled: true
    },
    {
      id: 'presentation',
      name: 'Presentation',
      description: 'Multi-page presentation style report',
      icon: 'bi-easel',
      disabled: true
    }
  ];

  return (
    <div className="wizard-page min-vh-100 bg-light">
      {/* Header */}
      <header className="bg-white shadow-sm py-3 mb-4">
        <div className="container">
          <div className="d-flex justify-content-between align-items-center">
            <h1 className="h4 mb-0 text-black1A">Create New Report</h1>
            <button
              className="btn btn-sm btn-outline-secondary"
              onClick={() => navigate('/')}
            >
              <i className="bi bi-x-lg me-2"></i>
              Cancel
            </button>
          </div>
        </div>
      </header>

      {/* Progress Steps */}
      <div className="container mb-4">
        <div className="row justify-content-center">
          <div className="col-md-8">
            <div className="d-flex align-items-center justify-content-between mb-4">
              <div className="d-flex align-items-center flex-fill">
                <div className={`step-circle ${step >= 1 ? 'active' : ''}`}>1</div>
                <div className="step-label ms-2 font-14">Basic Info</div>
              </div>
              <div className={`step-line ${step >= 2 ? 'active' : ''}`}></div>
              <div className="d-flex align-items-center flex-fill">
                <div className={`step-circle ${step >= 2 ? 'active' : ''}`}>2</div>
                <div className="step-label ms-2 font-14">Choose Template</div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Wizard Content */}
      <div className="container">
        <div className="row justify-content-center">
          <div className="col-md-8">
            <div className="card border-0 shadow-sm">
              <div className="card-body p-4">
                {/* Step 1: Basic Information */}
                {step === 1 && (
                  <div className="wizard-step">
                    <h2 className="h5 mb-4 text-black1A">Report Information</h2>

                    <div className="mb-4">
                      <label htmlFor="reportName" className="form-label font-14 fw-semibold">
                        Report Name <span className="text-danger">*</span>
                      </label>
                      <input
                        type="text"
                        className="form-control"
                        id="reportName"
                        name="name"
                        value={formData.name}
                        onChange={handleChange}
                        placeholder="Enter report name"
                        autoFocus
                      />
                    </div>

                    <div className="mb-4">
                      <label htmlFor="reportDescription" className="form-label font-14 fw-semibold">
                        Description (Optional)
                      </label>
                      <textarea
                        className="form-control"
                        id="reportDescription"
                        name="description"
                        value={formData.description}
                        onChange={handleChange}
                        rows="4"
                        placeholder="Enter a brief description of your report"
                      ></textarea>
                    </div>

                    <div className="d-flex justify-content-end gap-2">
                      <button
                        className="btn btn-outline-secondary"
                        onClick={() => navigate('/')}
                      >
                        Cancel
                      </button>
                      <button
                        className="btn btn-primary"
                        onClick={handleNext}
                      >
                        Next
                        <i className="bi bi-arrow-right ms-2"></i>
                      </button>
                    </div>
                  </div>
                )}

                {/* Step 2: Choose Template */}
                {step === 2 && (
                  <div className="wizard-step">
                    <h2 className="h5 mb-4 text-black1A">Choose a Template</h2>

                    <div className="row g-3 mb-4">
                      {templates.map((template) => (
                        <div key={template.id} className="col-md-6">
                          <div
                            className={`template-card p-3 border rounded h-100 ${
                              formData.template === template.id ? 'border-primary bg-light' : ''
                            } ${template.disabled ? 'opacity-50 cursor-not-allowed' : 'cursor-pointer'}`}
                            onClick={() => !template.disabled && setFormData(prev => ({ ...prev, template: template.id }))}
                          >
                            <div className="d-flex align-items-start">
                              <div className="template-icon me-3">
                                <i className={`bi ${template.icon} fs-2 ${formData.template === template.id ? 'text-primary' : 'text-muted'}`}></i>
                              </div>
                              <div className="flex-fill">
                                <h5 className="font-16 mb-1 text-black1A">
                                  {template.name}
                                  {template.disabled && (
                                    <span className="badge bg-secondary ms-2 font-12">Coming Soon</span>
                                  )}
                                </h5>
                                <p className="font-14 text-muted mb-0">{template.description}</p>
                              </div>
                              {formData.template === template.id && (
                                <i className="bi bi-check-circle-fill text-primary"></i>
                              )}
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>

                    <div className="d-flex justify-content-between">
                      <button
                        className="btn btn-outline-secondary"
                        onClick={handleBack}
                      >
                        <i className="bi bi-arrow-left me-2"></i>
                        Back
                      </button>
                      <button
                        className="btn btn-primary"
                        onClick={handleCreate}
                      >
                        <i className="bi bi-check-lg me-2"></i>
                        Create Report
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ReportWizard;
