import React, { useEffect, useRef } from 'react';
import PropTypes from 'prop-types';
import { createUniver, LocaleType, mergeLocales } from '@univerjs/presets';
import { UniverSheetsCorePreset } from '@univerjs/preset-sheets-core';
import enUS from '@univerjs/preset-sheets-core/locales/en-US';
import '@univerjs/preset-sheets-core/lib/index.css';

const UniverTableEditor = ({ tableData, onSave, onCancel }) => {
  const containerRef = useRef(null);
  const univerRef = useRef(null);
  const workbookRef = useRef(null);
  const isMounted = useRef(false);

  useEffect(() => {
    if (!containerRef.current || isMounted.current) return;
    isMounted.current = true;

    const { univer, univerAPI } = createUniver({
      locale: LocaleType.EN_US,
      locales: { [LocaleType.EN_US]: mergeLocales(enUS) },
      presets: [
        UniverSheetsCorePreset({ container: containerRef.current }),
      ],
    });

    // Convert table data to Univer format (nested cellData shape)
    const convertToUniverData = (data) => {
      const cellData = {};

      // Header row as row 0
      if (Array.isArray(data.headers)) {
        cellData[0] = {};
        data.headers.forEach((header, colIndex) => {
          cellData[0][colIndex] = {
            v: header,
            s: { bl: 1, bg: { rgb: '#cbd5e0' } },
          };
        });
      }

      // Data rows start at row 1
      if (Array.isArray(data.rows)) {
        data.rows.forEach((row, rowIndex) => {
          const r = rowIndex + 1;
          cellData[r] = {};
          row.forEach((cell, colIndex) => {
            cellData[r][colIndex] = { v: cell };
          });
        });
      }

      return {
        id: 'sheet-01',
        name: 'Table',
        tabColor: '',
        hidden: 0,
        rowCount: Math.max((data.rows?.length || 0) + 10, 20),
        columnCount: Math.max((data.headers?.length || 0) + 5, 10),
        zoomRatio: 1,
        freeze: { xSplit: 0, ySplit: 0, startRow: -1, startColumn: -1 },
        scrollTop: 0,
        scrollLeft: 0,
        defaultColumnWidth: 93,
        defaultRowHeight: 27,
        mergeData: [],
        cellData,
        rowData: {},
        columnData: {},
        showGridlines: 1,
        rowHeader: { width: 46, hidden: 0 },
        columnHeader: { height: 20, hidden: 0 },
        selections: ['A1'],
        rightToLeft: 0,
      };
    };

    // Create workbook with correct snapshot shape
    const sheetSnapshot = convertToUniverData(tableData);
    const workbookSnapshot = {
      id: 'workbook-01',
      name: 'Table Editor',
      appVersion: '0.1.0',
      locale: LocaleType.EN_US,
      styles: {},
      sheets: { [sheetSnapshot.id]: sheetSnapshot },
      sheetOrder: [sheetSnapshot.id],
      resources: [],
    };

    const fWorkbook = univerAPI.createWorkbook(workbookSnapshot);
    try { fWorkbook.setEditable(true); } catch {}
    const workbook = fWorkbook.getWorkbook();

    // Ensure active sheet and focus container for keyboard input
    try {
      workbook.ensureActiveSheet();
    } catch {}

    if (containerRef.current) {
      containerRef.current.tabIndex = 0;
      // defer to allow UI plugin mount
      setTimeout(() => containerRef.current && containerRef.current.focus(), 0);
    }
    univerRef.current = univer;
    workbookRef.current = workbook;

    return () => {
      isMounted.current = false;
      univer?.dispose();
      univerRef.current = null;
      workbookRef.current = null;
    };
  }, [tableData]);

  const handleSave = () => {
    if (!workbookRef.current) {
      onCancel();
      return;
    }

    try {
      const workbook = workbookRef.current;
      const sheet = workbook.getActiveSheet();

      if (!sheet) {
        console.error('No active sheet found');
        onCancel();
        return;
      }

      const { cellData } = sheet.getSnapshot();

      if (!cellData) {
        console.error('No cell data found');
        onCancel();
        return;
      }

      // Find actual data boundaries
      let maxRow = -1;
      let maxCol = -1;

      for (const row in cellData) {
        const rowIndex = parseInt(row, 10);
        if (rowIndex > maxRow) {
          maxRow = rowIndex;
        }
        for (const col in cellData[row]) {
          const colIndex = parseInt(col, 10);
          if (colIndex > maxCol) {
            maxCol = colIndex;
          }
        }
      }

      if (maxRow === -1 || maxCol === -1) {
        onSave({ headers: [], rows: [] });
        return;
      }

      // Convert Univer data back to table format
      const headers = [];
      for (let c = 0; c <= maxCol; c++) {
        headers.push(cellData[0]?.[c]?.v || '');
      }

      const rows = [];
      for (let r = 1; r <= maxRow; r++) {
        const rowData = [];
        for (let c = 0; c <= maxCol; c++) {
          rowData.push(cellData[r]?.[c]?.v || '');
        }
        if (rowData.some(cell => cell !== '')) {
          rows.push(rowData);
        }
      }

      onSave({ headers, rows });
    } catch (error) {
      console.error('Save failed:', error);
      onCancel();
    }
  };

  return (
    <div className="univer-host page-flex-col" style={{ width: '100%', height: '100%' }}>
      <div
        ref={containerRef}
        className="univer-mount grow"
        style={{
          width: '100%',
          flex: '1 1 auto',
          minHeight: 0,
        }}
      />
      <div
        style={{
          display: 'flex',
          justifyContent: 'flex-end',
          gap: '10px',
          padding: '15px',
          borderTop: '1px solid #e2e8f0',
          backgroundColor: '#ffffff',
        }}
      >
        <button
          type="button"
          onClick={onCancel}
          style={{
            padding: '8px 20px',
            border: '1px solid #cbd5e0',
            borderRadius: '4px',
            backgroundColor: '#ffffff',
            cursor: 'pointer',
            fontSize: '14px',
          }}
        >
          Cancel
        </button>
        <button
          type="button"
          onClick={handleSave}
          style={{
            padding: '8px 20px',
            border: 'none',
            borderRadius: '4px',
            backgroundColor: '#0d6efd',
            color: '#ffffff',
            cursor: 'pointer',
            fontSize: '14px',
            fontWeight: '500',
          }}
        >
          Save Changes
        </button>
      </div>
    </div>
  );
};

UniverTableEditor.propTypes = {
  tableData: PropTypes.shape({
    headers: PropTypes.array.isRequired,
    rows: PropTypes.array.isRequired,
  }).isRequired,
  onSave: PropTypes.func.isRequired,
  onCancel: PropTypes.func.isRequired,
};

export default UniverTableEditor;
