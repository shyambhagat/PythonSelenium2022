import React, { useState } from 'react';
import { createRoot } from 'react-dom/client';
import PropTypes from 'prop-types';
import {
  getStarterDataForChartType,
  normalizeTableDataToChart,
  parseCSV,
  parseJSON
} from '../../utils/chartDataUtils';

const ChartDataAttachment = ({ chartType, selectedTableElement, onAttach, onCancel }) => {
  const [mode, setMode] = useState(selectedTableElement ? 'useTable' : 'choose'); // useTable, choose, import
  const [importFormat, setImportFormat] = useState('csv'); // csv or json
  const [importText, setImportText] = useState('');
  const [importError, setImportError] = useState('');

  // Handle using selected table data
  const handleUseTableData = () => {
    if (!selectedTableElement || !selectedTableElement.tableData) {
      onAttach(getStarterDataForChartType(chartType));
      return;
    }

    const normalizedData = normalizeTableDataToChart(selectedTableElement.tableData, chartType);
    onAttach(normalizedData);
  };

  // Handle using sample data
  const handleUseSampleData = () => {
    const sampleData = getStarterDataForChartType(chartType);
    onAttach(sampleData);
  };


  // Handle opening import mode
  const handleOpenImport = () => {
    setMode('import');
  };

  // Handle import preview and apply
  const handleImportApply = () => {
    setImportError('');

    try {
      let tableData;

      if (importFormat === 'csv') {
        tableData = parseCSV(importText);
      } else if (importFormat === 'json') {
        tableData = parseJSON(importText);
      }

      if (!tableData || !tableData.headers || tableData.headers.length === 0) {
        setImportError('No data found. Please check your input format.');
        return;
      }

      const normalizedData = normalizeTableDataToChart(tableData, chartType);
      onAttach(normalizedData);
    } catch (error) {
      setImportError(`Error parsing ${importFormat.toUpperCase()}: ${error.message}`);
    }
  };

  // Render import mode
  if (mode === 'import') {
    return (
      <div
        className="chart-data-attachment-overlay"
        style={{
          position: 'fixed',
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          backgroundColor: 'rgba(0, 0, 0, 0.6)',
          display: 'flex',
          justifyContent: 'center',
          alignItems: 'center',
          zIndex: 10000
        }}
        onClick={(e) => {
          if (e.target === e.currentTarget) onCancel();
        }}
      >
        <div
          style={{
            backgroundColor: 'white',
            borderRadius: '8px',
            width: '90%',
            maxWidth: '700px',
            maxHeight: '80%',
            display: 'flex',
            flexDirection: 'column',
            boxShadow: '0 4px 20px rgba(0, 0, 0, 0.3)'
          }}
          onClick={(e) => e.stopPropagation()}
        >
          {/* Header */}
          <div style={{
            padding: '20px 24px',
            borderBottom: '1px solid #e0e0e0',
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center'
          }}>
            <h3 style={{ margin: 0, fontSize: '20px', fontWeight: 600 }}>
              Import Data
            </h3>
            <button
              onClick={onCancel}
              style={{
                background: 'none',
                border: 'none',
                fontSize: '24px',
                cursor: 'pointer',
                color: '#666',
                padding: '0 8px'
              }}
            >
              &times;
            </button>
          </div>

          {/* Content */}
          <div style={{
            flex: 1,
            padding: '24px',
            overflowY: 'auto'
          }}>
            {/* Format selector */}
            <div style={{ marginBottom: '20px' }}>
              <label style={{ display: 'block', marginBottom: '8px', fontWeight: 500 }}>
                Format
              </label>
              <div style={{ display: 'flex', gap: '12px' }}>
                {['csv', 'json'].map(format => (
                  <button
                    key={format}
                    onClick={() => {
                      setImportFormat(format);
                      setImportError('');
                    }}
                    style={{
                      padding: '8px 16px',
                      border: importFormat === format ? '2px solid #0d6efd' : '1px solid #ddd',
                      backgroundColor: importFormat === format ? '#e7f1ff' : 'white',
                      borderRadius: '4px',
                      cursor: 'pointer',
                      fontWeight: importFormat === format ? 600 : 400,
                      textTransform: 'uppercase',
                      fontSize: '14px'
                    }}
                  >
                    {format}
                  </button>
                ))}
              </div>
            </div>

            {/* Instructions */}
            <div style={{
              padding: '12px',
              backgroundColor: '#f8f9fa',
              borderRadius: '4px',
              marginBottom: '16px',
              fontSize: '13px',
              color: '#666'
            }}>
              {importFormat === 'csv' && (
                <>
                  <strong>CSV Format:</strong> First row = headers, subsequent rows = data
                  <br />
                  Example: <code style={{ fontSize: '12px' }}>Label,Value<br />Product A,35<br />Product B,28</code>
                </>
              )}
              {importFormat === 'json' && (
                <>
                  <strong>JSON Format:</strong> Array of objects
                  <br />
                  Example: <code style={{ fontSize: '12px' }}>[{`{"Label":"Product A","Value":35}`}, ...]</code>
                </>
              )}
            </div>

            {/* Text area */}
            <div style={{ marginBottom: '16px' }}>
              <label style={{ display: 'block', marginBottom: '8px', fontWeight: 500 }}>
                Paste your data
              </label>
              <textarea
                value={importText}
                onChange={(e) => {
                  setImportText(e.target.value);
                  setImportError('');
                }}
                placeholder={importFormat === 'csv'
                  ? 'Label,Value\nProduct A,35\nProduct B,28\nProduct C,22'
                  : '[{"Label":"Product A","Value":35},{"Label":"Product B","Value":28}]'
                }
                style={{
                  width: '100%',
                  minHeight: '200px',
                  padding: '12px',
                  border: '1px solid #ddd',
                  borderRadius: '4px',
                  fontFamily: 'monospace',
                  fontSize: '13px',
                  resize: 'vertical'
                }}
              />
            </div>

            {/* Error message */}
            {importError && (
              <div style={{
                padding: '12px',
                backgroundColor: '#f8d7da',
                color: '#721c24',
                borderRadius: '4px',
                fontSize: '14px',
                marginBottom: '16px'
              }}>
                {importError}
              </div>
            )}
          </div>

          {/* Footer */}
          <div style={{
            padding: '16px 24px',
            borderTop: '1px solid #e0e0e0',
            display: 'flex',
            justifyContent: 'space-between',
            gap: '12px'
          }}>
            <button
              onClick={() => setMode('choose')}
              style={{
                padding: '10px 16px',
                border: '1px solid #ddd',
                backgroundColor: 'white',
                borderRadius: '4px',
                cursor: 'pointer',
                fontSize: '14px'
              }}
            >
              &larr; Back
            </button>
            <div style={{ display: 'flex', gap: '12px' }}>
              <button
                onClick={onCancel}
                style={{
                  padding: '10px 24px',
                  border: '1px solid #ddd',
                  backgroundColor: 'white',
                  borderRadius: '4px',
                  cursor: 'pointer',
                  fontSize: '14px',
                  fontWeight: 500
                }}
              >
                Cancel
              </button>
              <button
                onClick={handleImportApply}
                disabled={!importText.trim()}
                style={{
                  padding: '10px 24px',
                  border: 'none',
                  backgroundColor: importText.trim() ? '#0d6efd' : '#ccc',
                  color: 'white',
                  borderRadius: '4px',
                  cursor: importText.trim() ? 'pointer' : 'not-allowed',
                  fontSize: '14px',
                  fontWeight: 500
                }}
              >
                Import Data
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Render use table prompt or chooser
  return (
    <div
      className="chart-data-attachment-overlay"
      style={{
        position: 'fixed',
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        backgroundColor: 'rgba(0, 0, 0, 0.6)',
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        zIndex: 10000
      }}
      onClick={(e) => {
        if (e.target === e.currentTarget) {
          handleUseSampleData(); // Fallback to sample if dismissed
        }
      }}
    >
      <div
        style={{
          backgroundColor: 'white',
          borderRadius: '8px',
          width: '90%',
          maxWidth: '500px',
          boxShadow: '0 4px 20px rgba(0, 0, 0, 0.3)',
          padding: '24px'
        }}
        onClick={(e) => e.stopPropagation()}
      >
        {/* Use table mode */}
        {mode === 'useTable' && selectedTableElement && (
          <>
            <h3 style={{ marginTop: 0, marginBottom: '16px', fontSize: '20px', fontWeight: 600 }}>
              Attach Data to Chart
            </h3>
            <p style={{ marginBottom: '24px', color: '#666', fontSize: '15px' }}>
              You have a table selected. Would you like to use its data for this chart?
            </p>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
              <button
                onClick={handleUseTableData}
                style={{
                  padding: '14px',
                  border: '2px solid #0d6efd',
                  backgroundColor: '#0d6efd',
                  color: 'white',
                  borderRadius: '6px',
                  cursor: 'pointer',
                  fontSize: '15px',
                  fontWeight: 600
                }}
              >
                Yes, use selected table data
              </button>
              <button
                onClick={() => setMode('choose')}
                style={{
                  padding: '14px',
                  border: '1px solid #ddd',
                  backgroundColor: 'white',
                  color: '#333',
                  borderRadius: '6px',
                  cursor: 'pointer',
                  fontSize: '15px',
                  fontWeight: 500
                }}
              >
                No, choose another option
              </button>
            </div>
          </>
        )}

        {/* Chooser mode */}
        {mode === 'choose' && (
          <>
            <h3 style={{ marginTop: 0, marginBottom: '16px', fontSize: '20px', fontWeight: 600 }}>
              Attach Data to Chart
            </h3>
            <p style={{ marginBottom: '20px', color: '#666', fontSize: '14px' }}>
              Choose how to add data to your chart:
            </p>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
              <button
                onClick={handleUseSampleData}
                style={{
                  padding: '16px',
                  border: '2px solid #0d6efd',
                  backgroundColor: '#e7f1ff',
                  color: '#0d6efd',
                  borderRadius: '6px',
                  cursor: 'pointer',
                  fontSize: '15px',
                  fontWeight: 600,
                  textAlign: 'left',
                  display: 'flex',
                  flexDirection: 'column',
                  gap: '4px'
                }}
              >
                <span style={{ fontSize: '16px' }}>
                  <i className="bi bi-graph-up" style={{ marginRight: '8px' }}></i>
                  Start with sample data
                </span>
                <span style={{ fontSize: '13px', fontWeight: 400, color: '#6c757d' }}>
                  Recommended - Edit later using "Edit Data" button
                </span>
              </button>
              <button
                onClick={handleOpenImport}
                style={{
                  padding: '16px',
                  border: '1px solid #ddd',
                  backgroundColor: 'white',
                  color: '#333',
                  borderRadius: '6px',
                  cursor: 'pointer',
                  fontSize: '15px',
                  fontWeight: 500,
                  textAlign: 'left',
                  display: 'flex',
                  flexDirection: 'column',
                  gap: '4px'
                }}
              >
                <span>
                  <i className="bi bi-file-earmark-arrow-up" style={{ marginRight: '8px' }}></i>
                  Import CSV or JSON
                </span>
                <span style={{ fontSize: '13px', fontWeight: 400, color: '#6c757d' }}>
                  Paste data from external sources
                </span>
              </button>
            </div>
          </>
        )}
      </div>
    </div>
  );
};

ChartDataAttachment.propTypes = {
  chartType: PropTypes.string.isRequired,
  selectedTableElement: PropTypes.object, // The currently selected table element (if any)
  onAttach: PropTypes.func.isRequired, // Callback with normalized dataSource
  onCancel: PropTypes.func.isRequired
};

export default ChartDataAttachment;

/**
 * Helper function to show ChartDataAttachment modal
 * @param {string} chartType - Type of chart being created
 * @param {object|null} selectedTableElement - Currently selected table element (if any)
 * @returns {Promise<object>} Resolves with normalized dataSource
 */
export function showChartDataAttachment(chartType, selectedTableElement = null) {
  return new Promise((resolve) => {
    const container = document.createElement('div');
    document.body.appendChild(container);
    document.body.style.overflow = 'hidden';

    const root = createRoot(container);

    const handleAttach = (dataSource) => {
      document.body.removeChild(container);
      document.body.style.overflow = '';
      root.unmount();
      resolve(dataSource);
    };

    const handleCancel = () => {
      document.body.removeChild(container);
      document.body.style.overflow = '';
      root.unmount();
      // Resolve with sample data as fallback
      resolve(getStarterDataForChartType(chartType));
    };

    root.render(
      <ChartDataAttachment
        chartType={chartType}
        selectedTableElement={selectedTableElement}
        onAttach={handleAttach}
        onCancel={handleCancel}
      />
    );
  });
}
