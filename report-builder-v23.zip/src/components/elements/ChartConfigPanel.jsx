import React, { useState, useMemo } from 'react';
import ReactECharts from 'echarts-for-react';
import {
  generateEChartsOption,
  convertDataSourceForChartType,
  dataSourceToTable,
  validateDataSource,
  getStarterDataForChartType
} from '../../utils/chartDataUtils';

const ChartConfigPanel = ({ element, onSave, onCancel }) => {
  const [activeTab, setActiveTab] = useState('type'); // type, appearance, data
  const [localConfig, setLocalConfig] = useState({
    chartType: element.chartType || 'bar',
    dataSource: element.dataSource || getStarterDataForChartType(element.chartType || 'bar'),
    chartTitle: element.chartTitle || '',
    showTitle: element.showTitle ?? true,
    showLegend: element.showLegend ?? true,
    showDataLabels: element.showDataLabels ?? false,
    bgColor: element.bgColor || '#ffffff',
    borderRadius: element.borderRadius ?? 6,
    colors: element.colors || [],
    showGrid: element.showGrid ?? true,
    xAxisTitle: element.xAxisTitle || '',
    yAxisTitle: element.yAxisTitle || '',
    animationEnabled: element.animationEnabled ?? true
  });

  // Validate dataSource
  const validatedDataSource = useMemo(() => {
    return validateDataSource(localConfig.dataSource);
  }, [localConfig.dataSource]);

  // Generate preview option
  const previewOption = useMemo(() => {
    return generateEChartsOption(validatedDataSource, localConfig.chartType, localConfig);
  }, [validatedDataSource, localConfig]);

  // Handle chart type change with data conversion
  const handleChartTypeChange = (newType) => {
    const convertedData = convertDataSourceForChartType(
      localConfig.dataSource,
      localConfig.chartType,
      newType
    );

    setLocalConfig(prev => ({
      ...prev,
      chartType: newType,
      dataSource: convertedData
    }));
  };

  // Handle configuration changes
  const updateConfig = (updates) => {
    setLocalConfig(prev => ({ ...prev, ...updates }));
  };

  // Handle color change for series/slices
  const handleColorChange = (index, color) => {
    const newColors = [...(localConfig.colors || [])];
    newColors[index] = color;
    updateConfig({ colors: newColors });
  };

  // Add new series color slot
  const addColorSlot = () => {
    const newColors = [...(localConfig.colors || [])];
    newColors.push('#5470c6');
    updateConfig({ colors: newColors });
  };

  // Handle save
  const handleSave = () => {
    onSave({
      chartType: localConfig.chartType,
      dataSource: validatedDataSource,
      chartTitle: localConfig.chartTitle,
      showTitle: localConfig.showTitle,
      showLegend: localConfig.showLegend,
      showDataLabels: localConfig.showDataLabels,
      bgColor: localConfig.bgColor,
      borderRadius: localConfig.borderRadius,
      colors: localConfig.colors,
      showGrid: localConfig.showGrid,
      xAxisTitle: localConfig.xAxisTitle,
      yAxisTitle: localConfig.yAxisTitle,
      animationEnabled: localConfig.animationEnabled
    });
  };

  // Convert dataSource to table format for preview
  const tableData = useMemo(() => {
    return dataSourceToTable(validatedDataSource);
  }, [validatedDataSource]);

  return (
    <div
      className="chart-config-modal-overlay"
      style={{
        position: 'fixed',
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        backgroundColor: 'rgba(0, 0, 0, 0.6)',
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        zIndex: 10000
      }}
      onClick={(e) => {
        if (e.target === e.currentTarget) onCancel();
      }}
    >
      <div
        className="chart-config-modal"
        style={{
          backgroundColor: 'white',
          borderRadius: '8px',
          width: '90%',
          maxWidth: '1200px',
          height: '85%',
          maxHeight: '800px',
          display: 'flex',
          flexDirection: 'column',
          boxShadow: '0 4px 20px rgba(0, 0, 0, 0.3)'
        }}
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div style={{
          padding: '20px 24px',
          borderBottom: '1px solid #e0e0e0',
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center'
        }}>
          <h3 style={{ margin: 0, fontSize: '20px', fontWeight: 600 }}>Configure Chart</h3>
          <button
            onClick={onCancel}
            style={{
              background: 'none',
              border: 'none',
              fontSize: '24px',
              cursor: 'pointer',
              color: '#666',
              padding: '0 8px'
            }}
          >
            &times;
          </button>
        </div>

        {/* Content Area: Tabs + Preview */}
        <div style={{
          flex: 1,
          display: 'flex',
          overflow: 'hidden'
        }}>
          {/* Left Panel: Configuration */}
          <div style={{
            width: '40%',
            borderRight: '1px solid #e0e0e0',
            display: 'flex',
            flexDirection: 'column'
          }}>
            {/* Tab Navigation */}
            <div style={{
              display: 'flex',
              borderBottom: '1px solid #e0e0e0',
              backgroundColor: '#f8f9fa'
            }}>
              {[
                { key: 'type', label: 'Chart Type' },
                { key: 'appearance', label: 'Appearance' },
                { key: 'data', label: 'Data Preview' }
              ].map(tab => (
                <button
                  key={tab.key}
                  onClick={() => setActiveTab(tab.key)}
                  style={{
                    flex: 1,
                    padding: '12px',
                    border: 'none',
                    backgroundColor: activeTab === tab.key ? 'white' : 'transparent',
                    borderBottom: activeTab === tab.key ? '2px solid #0d6efd' : 'none',
                    color: activeTab === tab.key ? '#0d6efd' : '#666',
                    fontWeight: activeTab === tab.key ? 600 : 400,
                    cursor: 'pointer',
                    transition: 'all 0.2s'
                }}
                >
                  {tab.label}
                </button>
              ))}
            </div>

            {/* Tab Content */}
            <div style={{
              flex: 1,
              overflowY: 'auto',
              padding: '20px'
            }}>
              {/* Chart Type Tab */}
              {activeTab === 'type' && (
                <div>
                  <h4 style={{ marginTop: 0, marginBottom: '16px', fontSize: '16px' }}>Select Chart Type</h4>
                  <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: '12px', maxHeight: '400px', overflowY: 'auto' }}>
                    {[
                      { type: 'stackedarea', label: 'Stacked Area' },
                      { type: 'line', label: 'Multi-Series Line' },
                      { type: 'pie', label: 'Pie Chart' },
                      { type: 'bar', label: 'Clustered Column' },
                      { type: 'column', label: 'Simple Column' },
                      { type: 'stackedbar', label: 'Stacked H. Bar' },
                      { type: 'grouped', label: 'Clustered Column (C)' },
                      { type: 'diverging', label: 'Diverging Bar' },
                      { type: 'range', label: 'Range/Floating Bar' },
                      { type: 'radial', label: 'Radial Progress' },
                      { type: 'marimekko', label: 'Marimekko' },
                      { type: 'horizontalbar', label: 'Horizontal Bar' },
                      { type: 'doughnut', label: 'Donut Chart' }
                    ].map(ct => (
                      <button
                        key={ct.type}
                        onClick={() => handleChartTypeChange(ct.type)}
                        style={{
                          padding: '12px',
                          border: localConfig.chartType === ct.type ? '2px solid #0d6efd' : '1px solid #ddd',
                          backgroundColor: localConfig.chartType === ct.type ? '#e7f1ff' : 'white',
                          borderRadius: '6px',
                          cursor: 'pointer',
                          fontWeight: localConfig.chartType === ct.type ? 600 : 400,
                          transition: 'all 0.2s'
                        }}
                      >
                        {ct.label}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Appearance Tab */}
              {activeTab === 'appearance' && (
                <div>
                  <h4 style={{ marginTop: 0, marginBottom: '16px', fontSize: '16px' }}>Chart Appearance</h4>

                  {/* Title */}
                  <div style={{ marginBottom: '20px' }}>
                    <label style={{ display: 'flex', alignItems: 'center', marginBottom: '8px' }}>
                      <input
                        type="checkbox"
                        checked={localConfig.showTitle}
                        onChange={(e) => updateConfig({ showTitle: e.target.checked })}
                        style={{ marginRight: '8px' }}
                      />
                      <span style={{ fontWeight: 500 }}>Show Title</span>
                    </label>
                    {localConfig.showTitle && (
                      <input
                        type="text"
                        value={localConfig.chartTitle}
                        onChange={(e) => updateConfig({ chartTitle: e.target.value })}
                        placeholder="Chart title"
                        style={{
                          width: '100%',
                          padding: '8px',
                          border: '1px solid #ddd',
                          borderRadius: '4px',
                          fontSize: '14px'
                        }}
                      />
                    )}
                  </div>

                  {/* Legend */}
                  <div style={{ marginBottom: '20px' }}>
                    <label style={{ display: 'flex', alignItems: 'center' }}>
                      <input
                        type="checkbox"
                        checked={localConfig.showLegend}
                        onChange={(e) => updateConfig({ showLegend: e.target.checked })}
                        style={{ marginRight: '8px' }}
                      />
                      <span style={{ fontWeight: 500 }}>Show Legend</span>
                    </label>
                  </div>

                  {/* Data Labels */}
                  <div style={{ marginBottom: '20px' }}>
                    <label style={{ display: 'flex', alignItems: 'center' }}>
                      <input
                        type="checkbox"
                        checked={localConfig.showDataLabels}
                        onChange={(e) => updateConfig({ showDataLabels: e.target.checked })}
                        style={{ marginRight: '8px' }}
                      />
                      <span style={{ fontWeight: 500 }}>Show Data Labels</span>
                    </label>
                  </div>

                  {/* Animations */}
                  <div style={{ marginBottom: '20px' }}>
                    <label style={{ display: 'flex', alignItems: 'center' }}>
                      <input
                        type="checkbox"
                        checked={localConfig.animationEnabled}
                        onChange={(e) => updateConfig({ animationEnabled: e.target.checked })}
                        style={{ marginRight: '8px' }}
                      />
                      <span style={{ fontWeight: 500 }}>Enable Animations</span>
                    </label>
                  </div>

                  {/* Background Color */}
                  <div style={{ marginBottom: '20px' }}>
                    <label style={{ display: 'block', marginBottom: '8px', fontWeight: 500 }}>
                      Background Color
                    </label>
                    <input
                      type="color"
                      value={localConfig.bgColor}
                      onChange={(e) => updateConfig({ bgColor: e.target.value })}
                      style={{ width: '60px', height: '36px', border: '1px solid #ddd', borderRadius: '4px' }}
                    />
                  </div>

                  {/* Border Radius (for bar charts) */}
                  {['bar', 'stacked'].includes(localConfig.chartType) && (
                    <div style={{ marginBottom: '20px' }}>
                      <label style={{ display: 'block', marginBottom: '8px', fontWeight: 500 }}>
                        Border Radius: {localConfig.borderRadius}px
                      </label>
                      <input
                        type="range"
                        min="0"
                        max="20"
                        value={localConfig.borderRadius}
                        onChange={(e) => updateConfig({ borderRadius: Number(e.target.value) })}
                        style={{ width: '100%' }}
                      />
                    </div>
                  )}

                  {/* Series/Slice Colors */}
                  <div style={{ marginBottom: '20px' }}>
                    <label style={{ display: 'block', marginBottom: '8px', fontWeight: 500 }}>
                      Colors
                    </label>
                    <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px' }}>
                      {(localConfig.colors || []).map((color, idx) => (
                        <input
                          key={idx}
                          type="color"
                          value={color}
                          onChange={(e) => handleColorChange(idx, e.target.value)}
                          style={{ width: '40px', height: '40px', border: '1px solid #ddd', borderRadius: '4px', cursor: 'pointer' }}
                        />
                      ))}
                      <button
                        onClick={addColorSlot}
                        style={{
                          width: '40px',
                          height: '40px',
                          border: '2px dashed #ddd',
                          borderRadius: '4px',
                          backgroundColor: 'white',
                          cursor: 'pointer',
                          fontSize: '20px',
                          color: '#666'
                        }}
                      >
                        +
                      </button>
                    </div>
                  </div>

                  {/* XY Chart specific options */}
                  {validatedDataSource.kind === 'xy' && (
                    <>
                      <div style={{ marginBottom: '20px' }}>
                        <label style={{ display: 'flex', alignItems: 'center', marginBottom: '8px' }}>
                          <input
                            type="checkbox"
                            checked={localConfig.showGrid}
                            onChange={(e) => updateConfig({ showGrid: e.target.checked })}
                            style={{ marginRight: '8px' }}
                          />
                          <span style={{ fontWeight: 500 }}>Show Grid Lines</span>
                        </label>
                      </div>

                      <div style={{ marginBottom: '20px' }}>
                        <label style={{ display: 'block', marginBottom: '8px', fontWeight: 500 }}>
                          X-Axis Title
                        </label>
                        <input
                          type="text"
                          value={localConfig.xAxisTitle}
                          onChange={(e) => updateConfig({ xAxisTitle: e.target.value })}
                          placeholder="X-Axis title"
                          style={{
                            width: '100%',
                            padding: '8px',
                            border: '1px solid #ddd',
                            borderRadius: '4px',
                            fontSize: '14px'
                          }}
                        />
                      </div>

                      <div style={{ marginBottom: '20px' }}>
                        <label style={{ display: 'block', marginBottom: '8px', fontWeight: 500 }}>
                          Y-Axis Title
                        </label>
                        <input
                          type="text"
                          value={localConfig.yAxisTitle}
                          onChange={(e) => updateConfig({ yAxisTitle: e.target.value })}
                          placeholder="Y-Axis title"
                          style={{
                            width: '100%',
                            padding: '8px',
                            border: '1px solid #ddd',
                            borderRadius: '4px',
                            fontSize: '14px'
                          }}
                        />
                      </div>
                    </>
                  )}
                </div>
              )}

              {/* Data Preview Tab */}
              {activeTab === 'data' && (
                <div>
                  <h4 style={{ marginTop: 0, marginBottom: '16px', fontSize: '16px' }}>Data Preview</h4>
                  <div style={{
                    overflowX: 'auto',
                    border: '1px solid #ddd',
                    borderRadius: '4px'
                  }}>
                    <table style={{
                      width: '100%',
                      borderCollapse: 'collapse',
                      fontSize: '14px'
                    }}>
                      <thead>
                        <tr style={{ backgroundColor: '#f8f9fa' }}>
                          {tableData.headers.map((header, idx) => (
                            <th key={idx} style={{
                              padding: '10px',
                              textAlign: 'left',
                              borderBottom: '2px solid #ddd',
                              fontWeight: 600
                            }}>
                              {header}
                            </th>
                          ))}
                        </tr>
                      </thead>
                      <tbody>
                        {tableData.rows.map((row, rowIdx) => (
                          <tr key={rowIdx} style={{
                            backgroundColor: rowIdx % 2 === 0 ? 'white' : '#f8f9fa'
                          }}>
                            {row.map((cell, cellIdx) => (
                              <td key={cellIdx} style={{
                                padding: '8px 10px',
                                borderBottom: '1px solid #e9ecef'
                              }}>
                                {cell}
                              </td>
                            ))}
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                  <p style={{
                    marginTop: '12px',
                    fontSize: '13px',
                    color: '#666',
                    fontStyle: 'italic'
                  }}>
                    Use the "Edit Data" button to modify chart data.
                  </p>
                </div>
              )}
            </div>
          </div>

          {/* Right Panel: Live Preview */}
          <div style={{
            flex: 1,
            display: 'flex',
            flexDirection: 'column',
            padding: '24px',
            backgroundColor: '#f8f9fa'
          }}>
            <h4 style={{ marginTop: 0, marginBottom: '16px', fontSize: '16px', color: '#666' }}>
              Live Preview
            </h4>
            <div style={{
              flex: 1,
              backgroundColor: localConfig.bgColor,
              borderRadius: '8px',
              border: '1px solid #ddd',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              minHeight: '300px'
            }}>
              <ReactECharts
                option={previewOption}
                style={{ width: '100%', height: '100%', minHeight: '300px' }}
                opts={{ renderer: 'canvas' }}
              />
            </div>
          </div>
        </div>

        {/* Footer: Action Buttons */}
        <div style={{
          padding: '16px 24px',
          borderTop: '1px solid #e0e0e0',
          display: 'flex',
          justifyContent: 'flex-end',
          gap: '12px'
        }}>
          <button
            onClick={onCancel}
            style={{
              padding: '10px 24px',
              border: '1px solid #ddd',
              backgroundColor: 'white',
              borderRadius: '4px',
              cursor: 'pointer',
              fontSize: '14px',
              fontWeight: 500
            }}
          >
            Cancel
          </button>
          <button
            onClick={handleSave}
            style={{
              padding: '10px 24px',
              border: 'none',
              backgroundColor: '#0d6efd',
              color: 'white',
              borderRadius: '4px',
              cursor: 'pointer',
              fontSize: '14px',
              fontWeight: 500
            }}
          >
            Apply Changes
          </button>
        </div>
      </div>
    </div>
  );
};

export default ChartConfigPanel;
