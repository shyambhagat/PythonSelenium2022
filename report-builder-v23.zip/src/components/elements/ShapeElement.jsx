import React, { useState, useRef, useEffect, useCallback } from 'react';
import PropTypes from 'prop-types';
import Swal from 'sweetalert2';

const MIN_WIDTH = 50;
const MIN_HEIGHT = 50;

const ShapeElement = ({ element, onUpdate, onSelect, onDelete, isSelected }) => {
  const [isDragging, setIsDragging] = useState(false);
  const [dragOffset, setDragOffset] = useState({ x: 0, y: 0 });
  const [isResizing, setIsResizing] = useState(false);
  const [resizeDirection, setResizeDirection] = useState(null);

  const elementRef = useRef(null);
  const resizeStateRef = useRef(null);

  const shapeType = element.shapeType || 'rectangle';
  const fillColor = element.fillColor || '#3b82f6';
  const borderColor = element.borderColor || '#1e40af';
  const borderWidth = element.borderWidth || 2;

  // Render SVG shape
  const renderShape = () => {
    const width = element.width || 150;
    const height = element.height || 150;

    switch (shapeType) {
      case 'rectangle':
        return (
          <rect
            x={borderWidth}
            y={borderWidth}
            width={width - borderWidth * 2}
            height={height - borderWidth * 2}
            fill={fillColor}
            stroke={borderColor}
            strokeWidth={borderWidth}
            rx="4"
          />
        );
      case 'circle':
        return (
          <circle
            cx={width / 2}
            cy={height / 2}
            r={Math.min(width, height) / 2 - borderWidth}
            fill={fillColor}
            stroke={borderColor}
            strokeWidth={borderWidth}
          />
        );
      case 'triangle':
        return (
          <polygon
            points={`${width / 2},${borderWidth * 2} ${width - borderWidth * 2},${height - borderWidth * 2} ${borderWidth * 2},${height - borderWidth * 2}`}
            fill={fillColor}
            stroke={borderColor}
            strokeWidth={borderWidth}
          />
        );
      case 'ellipse':
        return (
          <ellipse
            cx={width / 2}
            cy={height / 2}
            rx={width / 2 - borderWidth}
            ry={height / 2 - borderWidth}
            fill={fillColor}
            stroke={borderColor}
            strokeWidth={borderWidth}
          />
        );
      case 'star':
        const points = [];
        const outerRadius = Math.min(width, height) / 2 - borderWidth * 2;
        const innerRadius = outerRadius / 2.5;
        const centerX = width / 2;
        const centerY = height / 2;
        for (let i = 0; i < 10; i++) {
          const radius = i % 2 === 0 ? outerRadius : innerRadius;
          const angle = (i * Math.PI) / 5 - Math.PI / 2;
          const x = centerX + radius * Math.cos(angle);
          const y = centerY + radius * Math.sin(angle);
          points.push(`${x},${y}`);
        }
        return (
          <polygon
            points={points.join(' ')}
            fill={fillColor}
            stroke={borderColor}
            strokeWidth={borderWidth}
          />
        );
      case 'arrow':
        return (
          <path
            d={`M ${borderWidth * 2} ${height / 2} L ${width - height / 3} ${height / 2} L ${width - height / 3} ${borderWidth * 2} L ${width - borderWidth * 2} ${height / 2} L ${width - height / 3} ${height - borderWidth * 2} L ${width - height / 3} ${height / 2} Z`}
            fill={fillColor}
            stroke={borderColor}
            strokeWidth={borderWidth}
          />
        );
      default:
        return null;
    }
  };

  // Handle mouse down for dragging
  const handleMouseDown = (e) => {
    if (isResizing) return;
    if (e.target.closest('.shape-element-actions')) return;
    if (e.target.closest('.resize-handle')) return;

    e.preventDefault();
    e.stopPropagation();
    if (onSelect) onSelect(element.id);

    setIsDragging(true);
    const rect = elementRef.current.getBoundingClientRect();
    setDragOffset({
      x: e.clientX - rect.left,
      y: e.clientY - rect.top,
    });
  };

  // Handle mouse move for dragging
  const handleMouseMove = useCallback((e) => {
    if (!isDragging || isResizing) return;

    const canvas = elementRef.current.parentElement;
    const canvasRect = canvas.getBoundingClientRect();

    const newX = e.clientX - canvasRect.left - dragOffset.x;
    const newY = e.clientY - canvasRect.top - dragOffset.y;

    updateElement({
      x: Math.max(0, newX),
      y: Math.max(0, newY),
    });
  }, [isDragging, isResizing, dragOffset]);

  const handleMouseUp = useCallback(() => {
    setIsDragging(false);
  }, []);

  useEffect(() => {
    if (isDragging) {
      document.addEventListener('mousemove', handleMouseMove);
      document.addEventListener('mouseup', handleMouseUp);
      return () => {
        document.removeEventListener('mousemove', handleMouseMove);
        document.removeEventListener('mouseup', handleMouseUp);
      };
    }
  }, [isDragging, handleMouseMove, handleMouseUp]);

  // Handle resize mouse down
  const handleResizeMouseDown = (event, direction) => {
    if (!elementRef.current || !elementRef.current.parentElement) return;

    event.preventDefault();
    event.stopPropagation();
    if (onSelect) onSelect(element.id);

    const elementRect = elementRef.current.getBoundingClientRect();
    const containerRect = elementRef.current.parentElement.getBoundingClientRect();

    resizeStateRef.current = {
      startX: event.clientX,
      startY: event.clientY,
      width: elementRect.width,
      height: elementRect.height,
      x: elementRect.left - containerRect.left,
      y: elementRect.top - containerRect.top,
    };

    setResizeDirection(direction);
    setIsResizing(true);
  };

  // Handle resize
  useEffect(() => {
    if (!isResizing || !resizeDirection) return undefined;

    const handleResizeMouseMove = (event) => {
      event.preventDefault();
      if (!resizeStateRef.current) return;

      const { startX, startY, width, height, x, y } = resizeStateRef.current;
      const deltaX = event.clientX - startX;
      const deltaY = event.clientY - startY;

      let nextWidth = width;
      let nextHeight = height;
      let nextX = x;
      let nextY = y;

      if (resizeDirection.includes('e')) nextWidth = Math.max(MIN_WIDTH, width + deltaX);
      if (resizeDirection.includes('s')) nextHeight = Math.max(MIN_HEIGHT, height + deltaY);
      if (resizeDirection.includes('w')) {
        nextWidth = Math.max(MIN_WIDTH, width - deltaX);
        nextX = x + deltaX;
      }
      if (resizeDirection.includes('n')) {
        nextHeight = Math.max(MIN_HEIGHT, height - deltaY);
        nextY = y + deltaY;
      }

      updateElement({
        width: nextWidth,
        height: nextHeight,
        x: Math.max(0, nextX),
        y: Math.max(0, nextY),
      });
    };

    const handleResizeMouseUp = () => {
      setIsResizing(false);
      setResizeDirection(null);
      resizeStateRef.current = null;
    };

    document.addEventListener('mousemove', handleResizeMouseMove);
    document.addEventListener('mouseup', handleResizeMouseUp);

    return () => {
      document.removeEventListener('mousemove', handleResizeMouseMove);
      document.removeEventListener('mouseup', handleResizeMouseUp);
    };
  }, [isResizing, resizeDirection]);

  const updateElement = (updates) => {
    if (onUpdate) onUpdate(element.id, updates);
  };

  const handleEditClick = (event) => {
    event.stopPropagation();
    Swal.fire({
      title: 'Shape Editor',
      html: `
        <div style="text-align: left;">
          <p style="font-size: 14px; color: #666;">Edit shape properties:</p>
          <ul style="font-size: 13px; color: #666; text-align: left; padding-left: 20px;">
            <li>Change shape type</li>
            <li>Adjust fill and border colors</li>
            <li>Modify border width</li>
            <li>Add rotation</li>
          </ul>
          <p style="font-size: 12px; color: #999; margin-top: 15px;">
            Shape editor coming soon!
          </p>
        </div>
      `,
      icon: 'info',
      confirmButtonText: 'Got it',
      heightAuto: false,
    });
  };

  const handleDeleteClick = (event) => {
    event.stopPropagation();

    Swal.fire({
      title: 'Delete Shape?',
      text: 'This action cannot be undone.',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#dc3545',
      cancelButtonColor: '#6c757d',
      confirmButtonText: 'Yes, delete it',
      cancelButtonText: 'Cancel',
      heightAuto: false
    }).then((result) => {
      if (result.isConfirmed && onDelete) {
        onDelete(element.id);
      }
    });
  };

  useEffect(() => {
    if (!isSelected) return undefined;

    const handleDeleteKey = (event) => {
      if (event.key === 'Delete') {
        event.preventDefault();
        if (onDelete) onDelete(element.id);
      }
    };

    document.addEventListener('keydown', handleDeleteKey);
    return () => document.removeEventListener('keydown', handleDeleteKey);
  }, [isSelected, onDelete, element.id]);

  return (
    <div
      ref={elementRef}
      className={`shape-element-wrapper ${isSelected ? 'selected' : ''}`}
      style={{
        left: `${element.x}px`,
        top: `${element.y}px`,
        width: element.width ? `${element.width}px` : '150px',
        height: element.height ? `${element.height}px` : '150px',
      }}
    >
      <div className="shape-element-actions">
        <button
          type="button"
          className="shape-element-action-btn"
          aria-label="Edit shape"
          title="Edit shape"
          onClick={handleEditClick}
        >
          <i className="bi bi-palette"></i>
        </button>
        <button
          type="button"
          className="shape-element-action-btn shape-element-action-danger"
          aria-label="Delete shape"
          title="Delete shape"
          onClick={handleDeleteClick}
        >
          <i className="bi bi-trash"></i>
        </button>
      </div>

      <div className="shape-drag-overlay" onMouseDown={handleMouseDown} />

      <div className="shape-element-content">
        <svg
          width="100%"
          height="100%"
          viewBox={`0 0 ${element.width || 150} ${element.height || 150}`}
          preserveAspectRatio="none"
        >
          {renderShape()}
        </svg>
      </div>

      {isSelected && (
        <>
          <div className="resize-handle nw" onMouseDown={(event) => handleResizeMouseDown(event, 'nw')}></div>
          <div className="resize-handle ne" onMouseDown={(event) => handleResizeMouseDown(event, 'ne')}></div>
          <div className="resize-handle sw" onMouseDown={(event) => handleResizeMouseDown(event, 'sw')}></div>
          <div className="resize-handle se" onMouseDown={(event) => handleResizeMouseDown(event, 'se')}></div>
          <div className="resize-handle n" onMouseDown={(event) => handleResizeMouseDown(event, 'n')}></div>
          <div className="resize-handle s" onMouseDown={(event) => handleResizeMouseDown(event, 's')}></div>
          <div className="resize-handle w" onMouseDown={(event) => handleResizeMouseDown(event, 'w')}></div>
          <div className="resize-handle e" onMouseDown={(event) => handleResizeMouseDown(event, 'e')}></div>
        </>
      )}
    </div>
  );
};

ShapeElement.propTypes = {
  element: PropTypes.shape({
    id: PropTypes.oneOfType([PropTypes.number, PropTypes.string]).isRequired,
    type: PropTypes.string.isRequired,
    x: PropTypes.number.isRequired,
    y: PropTypes.number.isRequired,
    width: PropTypes.number,
    height: PropTypes.number,
    shapeType: PropTypes.string,
    fillColor: PropTypes.string,
    borderColor: PropTypes.string,
    borderWidth: PropTypes.number,
  }).isRequired,
  onUpdate: PropTypes.func,
  onSelect: PropTypes.func,
  onDelete: PropTypes.func,
  isSelected: PropTypes.bool,
};

export default ShapeElement;
