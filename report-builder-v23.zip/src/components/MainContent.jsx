import React, { useState, useEffect, useRef } from 'react';
import PropTypes from 'prop-types';
import { useReports } from '../context/ReportContext';
import { TEXT_STYLE_DRAG_TYPE, CHART_DRAG_TYPE, IMAGE_DRAG_TYPE, TABLE_DRAG_TYPE, SHAPE_DRAG_TYPE } from '../constants/dragTypes';
import TextElement from './elements/TextElement';
import ChartElement from './elements/ChartElement';
import ImageElement from './elements/ImageElement';
import TableElement from './elements/TableElement';
import ShapeElement from './elements/ShapeElement';
import { showChartDataAttachment } from './elements/ChartDataAttachment';

const MainContent = ({
  reportId,
  report,
  activePageId,
  onActivePageChange,
  gridEnabled,
  zoomValue = 100,
  contentRef,
  onElementSelect: onElementSelectProp,
}) => {
  const { addPage, addElementToPage, updateElementOnPage, removeElementFromPage, duplicateElement } = useReports();
  const [activePage, setActivePage] = useState(activePageId || report?.pages?.[0]?.id || 'page-1');
  const [selectedElement, setSelectedElement] = useState(null);
  const [dragOverPage, setDragOverPage] = useState(null);
  const [pendingAutoFocusId, setPendingAutoFocusId] = useState(null);
  const dragCounterRef = useRef({});
  const [interaction, setInteraction] = useState(null);

  const handlePageChange = (pageId) => {
    setActivePage(pageId);
    setSelectedElement(null);
    if (onActivePageChange) {
      onActivePageChange(pageId);
    }
  };

  const pages = report?.pages || [];

  const handleAddPage = () => {
    addPage(reportId);
  };

  useEffect(() => {
    setSelectedElement(null);
  }, [reportId]);

  // Keyboard shortcuts for copy/duplicate
  useEffect(() => {
    const handleKeyDown = (e) => {
      // Ctrl+D or Ctrl+C to duplicate selected element
      if ((e.ctrlKey || e.metaKey) && (e.key === 'd' || e.key === 'c') && selectedElement) {
        e.preventDefault();
        duplicateElement(reportId, selectedElement.pageId, selectedElement.elementId);
      }
      // Delete key to remove selected element
      if ((e.key === 'Delete' || e.key === 'Backspace') && selectedElement) {
        // Only delete if not currently editing a text element
        const activeElement = document.activeElement;
        const isEditingText = activeElement && (
          activeElement.hasAttribute('contenteditable') ||
          activeElement.tagName === 'INPUT' ||
          activeElement.tagName === 'TEXTAREA'
        );
        if (!isEditingText) {
          e.preventDefault();
          removeElementFromPage(reportId, selectedElement.pageId, selectedElement.elementId);
          setSelectedElement(null);
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [selectedElement, reportId, duplicateElement, removeElementFromPage]);

  useEffect(() => {
    setSelectedElement(null);
  }, [activePage]);

  // Keep local activePage in sync with prop
  useEffect(() => {
    if (activePageId && activePageId !== activePage) {
      setActivePage(activePageId);
    }
  }, [activePageId]);

  const handleElementSelect = (pageId, elementId) => {
    const selection = { pageId, elementId };
    setSelectedElement(selection);
    if (onElementSelectProp) {
      onElementSelectProp(selection);
    }
  };

  const handleElementUpdate = (pageId, elementId, updates) => {
    updateElementOnPage(reportId, pageId, elementId, updates);
  };

  const handleElementDelete = (pageId, elementId) => {
    removeElementFromPage(reportId, pageId, elementId);
    if (selectedElement?.pageId === pageId && selectedElement?.elementId === elementId) {
      setSelectedElement(null);
    }
    if (pendingAutoFocusId === elementId) {
      setPendingAutoFocusId(null);
    }
  };

  const handleCanvasMouseDown = (event) => {
    const target = event.target;
    const isTextElement = target && target.closest ? target.closest('.text-element-wrapper') : null;
    const isChartElement = target && target.closest ? target.closest('.chart-element-wrapper') : null;
    const isImageElement = target && target.closest ? target.closest('.image-element-wrapper') : null;
    const isTableElement = target && target.closest ? target.closest('.table-element-wrapper') : null;
    const isShapeElement = target && target.closest ? target.closest('.shape-element-wrapper') : null;
    if (!isTextElement && !isChartElement && !isImageElement && !isTableElement && !isShapeElement) {
      setSelectedElement(null);
      if (onElementSelectProp) {
        onElementSelectProp(null);
      }
    }
  };

  const isElementDrag = (event) => {
    const types = event.dataTransfer?.types;
    if (!types) {
      return false;
    }

    const typeList = Array.from(types);
    return typeList.includes(TEXT_STYLE_DRAG_TYPE) ||
           typeList.includes(CHART_DRAG_TYPE) ||
           typeList.includes(IMAGE_DRAG_TYPE) ||
           typeList.includes(TABLE_DRAG_TYPE) ||
           typeList.includes(SHAPE_DRAG_TYPE) ||
           typeList.includes('text/plain');
  };

  const handleDragEnterCanvas = (event, pageId) => {
    if (!isElementDrag(event)) {
      return;
    }

    event.preventDefault();
    dragCounterRef.current[pageId] = (dragCounterRef.current[pageId] || 0) + 1;
    setDragOverPage(pageId);
  };

  const handleDragOverCanvas = (event) => {
    if (!isElementDrag(event)) {
      return;
    }

    event.preventDefault();
    event.dataTransfer.dropEffect = 'copy';
  };

  const handleDragLeaveCanvas = (event, pageId) => {
    if (!isElementDrag(event)) {
      return;
    }

    const currentCount = dragCounterRef.current[pageId] || 0;
    const nextCount = Math.max(0, currentCount - 1);
    dragCounterRef.current[pageId] = nextCount;

    if (nextCount === 0) {
      setDragOverPage(null);
    }
  };

  const handleDropOnCanvas = async (event, pageId) => {
    event.preventDefault();
    setDragOverPage(null);
    dragCounterRef.current[pageId] = 0;

    // Check all payload types
    const chartPayload = event.dataTransfer.getData(CHART_DRAG_TYPE);
    const imagePayload = event.dataTransfer.getData(IMAGE_DRAG_TYPE);
    const tablePayload = event.dataTransfer.getData(TABLE_DRAG_TYPE);
    const shapePayload = event.dataTransfer.getData(SHAPE_DRAG_TYPE);
    const textPayload = event.dataTransfer.getData(TEXT_STYLE_DRAG_TYPE);
    const plainTextPayload = event.dataTransfer.getData('text/plain');

    console.log('Drop detected:', { chartPayload, imagePayload, tablePayload, shapePayload, textPayload, plainTextPayload, types: event.dataTransfer.types });

    if (!textPayload && !chartPayload && !imagePayload && !tablePayload && !shapePayload && !plainTextPayload) {
      console.log('No valid payload found');
      return;
    }

    const canvasRect = event.currentTarget.getBoundingClientRect();
    const dropX = event.clientX - canvasRect.left;
    const dropY = event.clientY - canvasRect.top;
    const newElementId =
      (typeof crypto !== 'undefined' && crypto.randomUUID) ? crypto.randomUUID() : Date.now();

    // Process chart payload
    if (chartPayload) {
      console.log('Processing chart payload:', chartPayload);
      let chartData;
      try {
        chartData = JSON.parse(chartPayload);
        console.log('Parsed chart data:', chartData);
      } catch (error) {
        console.error('Failed to parse chart payload:', error);
        return;
      }

      if (chartData.type !== 'chart') {
        console.log('Invalid chart type:', chartData.type);
        return;
      }

      // Find the currently selected table element (if any)
      const currentPage = pages.find(p => p.id === pageId);
      let selectedTableElement = null;

      if (selectedElement && selectedElement.pageId === pageId && currentPage) {
        const element = currentPage.elements?.find(el => el.id === selectedElement.elementId);
        if (element && element.type === 'table') {
          selectedTableElement = element;
        }
      }

      // Show data attachment dialog and wait for user choice
      const dataSource = await showChartDataAttachment(
        chartData.chartType || 'bar',
        selectedTableElement
      );

      const newElement = {
        id: newElementId,
        type: 'chart',
        chartType: chartData.chartType || 'bar',
        chartTitle: chartData.chartName || '',
        showTitle: true,
        bgColor: '#ffffff',
        borderRadius: 6,
        showLegend: true,
        showDataLabels: true,
        dataSource: dataSource, // Attach the normalized data source
        x: Math.max(0, dropX - 200),
        y: Math.max(0, dropY - 150),
        width: 400,
        height: 300,
      };

      console.log('Creating chart element with dataSource:', newElement);
      addElementToPage(reportId, pageId, newElement);
      setSelectedElement({ pageId, elementId: newElementId });
      console.log('Chart element created successfully');
      return;
    }

    // Process image payload
    if (imagePayload) {
      let imageData;
      try {
        imageData = JSON.parse(imagePayload);
      } catch (error) {
        console.error('Failed to parse image payload:', error);
        return;
      }

      if (imageData.type !== 'image') {
        return;
      }

      const newElement = {
        id: newElementId,
        type: 'image',
        imageUrl: imageData.imageUrl || '',
        alt: imageData.alt || 'Image',
        x: Math.max(0, dropX - 100),
        y: Math.max(0, dropY - 100),
        width: 200,
        height: 200,
      };

      addElementToPage(reportId, pageId, newElement);
      setSelectedElement({ pageId, elementId: newElementId });
      return;
    }

    // Process table payload
    if (tablePayload) {
      let tableData;
      try {
        tableData = JSON.parse(tablePayload);
      } catch (error) {
        console.error('Failed to parse table payload:', error);
        return;
      }

      if (tableData.type !== 'table') {
        return;
      }

      const newElement = {
        id: newElementId,
        type: 'table',
        tableData: tableData.tableData,
        x: Math.max(0, dropX - 150),
        y: Math.max(0, dropY - 75),
        width: 300,
        height: 150,
      };

      addElementToPage(reportId, pageId, newElement);
      setSelectedElement({ pageId, elementId: newElementId });
      return;
    }

    // Process shape payload
    if (shapePayload) {
      let shapeData;
      try {
        shapeData = JSON.parse(shapePayload);
      } catch (error) {
        console.error('Failed to parse shape payload:', error);
        return;
      }

      if (shapeData.type !== 'shape') {
        return;
      }

      const newElement = {
        id: newElementId,
        type: 'shape',
        shapeType: shapeData.shapeType || 'rectangle',
        fillColor: shapeData.fillColor || '#93c5fd',
        borderColor: shapeData.borderColor || '#3b82f6',
        borderWidth: shapeData.borderWidth || 2,
        x: Math.max(0, dropX - 75),
        y: Math.max(0, dropY - 75),
        width: 150,
        height: 150,
      };

      addElementToPage(reportId, pageId, newElement);
      setSelectedElement({ pageId, elementId: newElementId });
      return;
    }

    // Process text payload
    if (textPayload || plainTextPayload) {
      const payload = textPayload || plainTextPayload;
      let textStyle;
      try {
        textStyle = JSON.parse(payload);
      } catch (error) {
        return;
      }

      if (textStyle.type !== 'text') {
        return;
      }

      const newElement = {
        id: newElementId,
        type: 'text',
        content: '',
        fontSize: Number(textStyle.fontSize) || 16,
        fontWeight: textStyle.fontWeight || 'normal',
        fontStyle: 'normal',
        textAlign: 'left',
        textColor: '#1a1a1a',
        x: Math.max(0, dropX - 10),
        y: Math.max(0, dropY - 10),
        width: 240,
        height: 60,
      };

      addElementToPage(reportId, pageId, newElement);
      setSelectedElement({ pageId, elementId: newElementId });
      setPendingAutoFocusId(newElementId);
    }
  };

  const handleElementMouseDown = (e, pageId, element) => {
    e.preventDefault();
    e.stopPropagation();

    const { clientX: startX, clientY: startY } = e;
    const { x, y, width, height } = element;

    let interactionType = 'move';
    const target = e.target;
    if (target.classList.contains('resize-handle')) {
        interactionType = target.classList.contains('nw') ? 'resize-nw' :
                          target.classList.contains('ne') ? 'resize-ne' :
                          target.classList.contains('sw') ? 'resize-sw' :
                          target.classList.contains('se') ? 'resize-se' :
                          target.classList.contains('n') ? 'resize-n' :
                          target.classList.contains('s') ? 'resize-s' :
                          target.classList.contains('w') ? 'resize-w' :
                          'resize-e';
    }

    setInteraction({
        type: interactionType,
        elementId: element.id,
        pageId: pageId,
        startX,
        startY,
        initialX: x,
        initialY: y,
        initialWidth: width,
        initialHeight: height,
    });
  };

  useEffect(() => {
    const handleMouseMove = (e) => {
        if (!interaction) return;

        const { clientX: currentX, clientY: currentY } = e;
        const { type, elementId, pageId, startX, startY, initialX, initialY, initialWidth, initialHeight } = interaction;

        const dx = currentX - startX;
        const dy = currentY - startY;

        if (type === 'move') {
            handleElementUpdate(pageId, elementId, {
                x: initialX + dx,
                y: initialY + dy,
            });
        } else if (type.startsWith('resize')) {
            let newX = initialX;
            let newY = initialY;
            let newWidth = initialWidth;
            let newHeight = initialHeight;

            if (type.includes('e')) newWidth = initialWidth + dx;
            if (type.includes('w')) {
                newWidth = initialWidth - dx;
                newX = initialX + dx;
            }
            if (type.includes('s')) newHeight = initialHeight + dy;
            if (type.includes('n')) {
                newHeight = initialHeight - dy;
                newY = initialY + dy;
            }

            handleElementUpdate(pageId, elementId, {
                x: newX,
                y: newY,
                width: Math.max(50, newWidth),
                height: Math.max(50, newHeight),
            });
        }
    };

    const handleMouseUp = () => {
        setInteraction(null);
    };

    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('mouseup', handleMouseUp);

    return () => {
        window.removeEventListener('mousemove', handleMouseMove);
        window.removeEventListener('mouseup', handleMouseUp);
    };
  }, [interaction, handleElementUpdate]);

  const currentPage = pages.find(p => p.id === activePage) || pages[0];

  // Page size mapping (mm) for A4 / Letter
  const PAGE_SIZES = {
    A4: { w: 210, h: 297 },
    Letter: { w: 216, h: 279 },
  };

  const pageStyle = React.useMemo(() => {
    const size = PAGE_SIZES[currentPage?.pageSize] || PAGE_SIZES.A4;
    const isLandscape = currentPage?.orientation === 'landscape';
    const w = isLandscape ? size.h : size.w;
    const h = isLandscape ? size.w : size.h;
    const scale = zoomValue / 100;
    return {
      '--page-width': `${w}mm`,
      '--page-height': `${h}mm`,
      transform: `scale(${scale})`,
      transformOrigin: 'top center',
    };
  }, [currentPage, zoomValue]);

  return (
    <div id="mainWrapper" className="mainWrapper flex-grow-1 w-100 pe-5 me-3">
      <div className="container-fluid px-0">
        <div className="bodyWrapper">
          <div
            ref={contentRef}
            className="canvas-body"
          >
            {currentPage && (
              <div
                className={`page-container ${gridEnabled ? 'gridblock' : ''} ${dragOverPage === currentPage.id ? 'is-drag-over' : ''}`}
                style={pageStyle}
                onMouseDown={handleCanvasMouseDown}
                onDragEnter={(event) => handleDragEnterCanvas(event, currentPage.id)}
                onDragOver={handleDragOverCanvas}
                onDragLeave={(event) => handleDragLeaveCanvas(event, currentPage.id)}
                onDrop={(event) => handleDropOnCanvas(event, currentPage.id)}
              >
                {currentPage.elements && currentPage.elements.length > 0 ? (
                  <>
                    {currentPage.elements.map((element) => {
                      const isSelected =
                        selectedElement?.pageId === currentPage.id && selectedElement?.elementId === element.id;

                      if (element.type === 'text') {
                        return (
                          <TextElement
                            key={element.id}
                            element={element}
                            isSelected={isSelected}
                            onSelect={(elementId) => handleElementSelect(currentPage.id, elementId)}
                            onUpdate={(elementId, updates) => handleElementUpdate(currentPage.id, elementId, updates)}
                            onDelete={(elementId) => handleElementDelete(currentPage.id, elementId)}
                            autoFocus={pendingAutoFocusId === element.id}
                            onAutoFocusComplete={() => setPendingAutoFocusId(null)}
                          />
                        );
                      } else if (element.type === 'chart') {
                        return (
                          <ChartElement
                            key={element.id}
                            element={element}
                            isSelected={isSelected}
                            onSelect={(elementId) => handleElementSelect(currentPage.id, elementId)}
                            onUpdate={(elementId, updates) => handleElementUpdate(currentPage.id, elementId, updates)}
                            onDelete={(elementId) => handleElementDelete(currentPage.id, elementId)}
                          />
                        );
                      } else if (element.type === 'image') {
                        return (
                          <ImageElement
                            key={element.id}
                            element={element}
                            isSelected={isSelected}
                            onSelect={(elementId) => handleElementSelect(currentPage.id, elementId)}
                            onUpdate={(elementId, updates) => handleElementUpdate(currentPage.id, elementId, updates)}
                            onDelete={(elementId) => handleElementDelete(currentPage.id, elementId)}
                          />
                        );
                      } else if (element.type === 'table') {
                        return (
                          <TableElement
                            key={element.id}
                            element={element}
                            isSelected={isSelected}
                            onSelect={(elementId) => handleElementSelect(currentPage.id, elementId)}
                            onUpdate={(elementId, updates) => handleElementUpdate(currentPage.id, elementId, updates)}
                            onDelete={(elementId) => handleElementDelete(currentPage.id, elementId)}
                          />
                        );
                      } else if (element.type === 'shape') {
                        return (
                          <ShapeElement
                            key={element.id}
                            element={element}
                            isSelected={isSelected}
                            onSelect={(elementId) => handleElementSelect(currentPage.id, elementId)}
                            onUpdate={(elementId, updates) => handleElementUpdate(currentPage.id, elementId, updates)}
                            onDelete={(elementId) => handleElementDelete(currentPage.id, elementId)}
                          />
                        );
                      }
                      return null;
                    })}
                  </>
                ) : (
                  <div className="empty-page-container text-center">
                    <div>
                      <img
                        src="/images/startReportBuild-icon.svg"
                        alt="Start report build icon"
                        width="52"
                        height="55"
                      />
                      <div className="font-14 font-medium mt-3 text-black1A">Start Building Your Report</div>
                      <div className="font-12 font-regular text-black75 mt-2">
                        Select a tool from the sidebar to add elements to this page
                      </div>
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

MainContent.propTypes = {
  reportId: PropTypes.string.isRequired,
  report: PropTypes.shape({
    id: PropTypes.string.isRequired,
    name: PropTypes.string.isRequired,
    description: PropTypes.string,
    createdAt: PropTypes.string.isRequired,
    updatedAt: PropTypes.string.isRequired,
    pages: PropTypes.arrayOf(
      PropTypes.shape({
        id: PropTypes.string.isRequired,
        name: PropTypes.string.isRequired,
        elements: PropTypes.array.isRequired,
      })
    ).isRequired,
  }).isRequired,
  activePageId: PropTypes.string,
  onActivePageChange: PropTypes.func,
  gridEnabled: PropTypes.bool,
  zoomValue: PropTypes.number,
  contentRef: PropTypes.oneOfType([
    PropTypes.func,
    PropTypes.shape({
      current: PropTypes.any,
    }),
  ]),
  onElementSelect: PropTypes.func,
};

export default MainContent;
