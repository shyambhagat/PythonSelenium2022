import React from 'react';
import PropTypes from 'prop-types';

const PAGE_SIZES = [
  { id: 'A4', label: 'A4 (210 × 297 mm)' },
  { id: 'Letter', label: 'Letter (216 × 279 mm)' },
];

const PageSettingsModal = ({ isOpen, onClose, page, onSave }) => {
  const [size, setSize] = React.useState(page?.pageSize || 'A4');
  const [orientation, setOrientation] = React.useState(page?.orientation || 'portrait');

  React.useEffect(() => {
    setSize(page?.pageSize || 'A4');
    setOrientation(page?.orientation || 'portrait');
  }, [page]);

  if (!isOpen) return null;

  const handleSubmit = (e) => {
    e.preventDefault();
    onSave({ pageSize: size, orientation });
  };

  return (
    <div className="page-settings-modal-overlay" role="dialog" aria-modal="true" aria-label="Page Settings">
      <div className="page-settings-modal">
        <div className="modal-header d-flex justify-content-between align-items-center">
          <h6 className="m-0">Page Settings</h6>
          <button type="button" className="btn btn-sm btn-light" onClick={onClose} aria-label="Close">×</button>
        </div>
        <form onSubmit={handleSubmit} className="modal-body">
          <div className="mb-3">
            <label className="form-label font-12 text-black75">Page Size</label>
            <select className="form-select" value={size} onChange={(e) => setSize(e.target.value)}>
              {PAGE_SIZES.map((s) => (
                <option key={s.id} value={s.id}>{s.label}</option>
              ))}
            </select>
          </div>
          <div className="mb-3">
            <label className="form-label font-12 text-black75 d-block">Orientation</label>
            <div className="d-flex gap-3">
              <div className="form-check">
                <input className="form-check-input" type="radio" name="orientation" id="orientPortrait" value="portrait"
                  checked={orientation === 'portrait'} onChange={() => setOrientation('portrait')} />
                <label className="form-check-label" htmlFor="orientPortrait">Portrait</label>
              </div>
              <div className="form-check">
                <input className="form-check-input" type="radio" name="orientation" id="orientLandscape" value="landscape"
                  checked={orientation === 'landscape'} onChange={() => setOrientation('landscape')} />
                <label className="form-check-label" htmlFor="orientLandscape">Landscape</label>
              </div>
            </div>
          </div>
          <div className="d-flex justify-content-end gap-2">
            <button type="button" className="btn btn-light" onClick={onClose}>Cancel</button>
            <button type="submit" className="btn btn-primary">Save</button>
          </div>
        </form>
      </div>
    </div>
  );
};

PageSettingsModal.propTypes = {
  isOpen: PropTypes.bool.isRequired,
  onClose: PropTypes.func.isRequired,
  onSave: PropTypes.func.isRequired,
  page: PropTypes.object,
};

export default PageSettingsModal;

